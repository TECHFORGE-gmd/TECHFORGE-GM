import pygame
import os
import random
from settings import HEIGHT
from sprites import surface_sprites, sewer_sprites

base = os.path.dirname(__file__)


def _build_platform_images(sprite, platforms):
    
    images = []
    for plat in platforms[1:]:
        images.append(
            pygame.transform.scale(sprite, (plat.width, plat.height))
        )
    return images


class SurfaceMap:
    def __init__(self):

        self.sprites = surface_sprites()

        self.platforms = [
            pygame.Rect(-100000, HEIGHT - 150, 200000, 150),

            pygame.Rect(600, HEIGHT - 250, 150, 30),
            pygame.Rect(425, HEIGHT - 350, 150, 30),
            pygame.Rect(820, HEIGHT - 350, 150, 30),
            pygame.Rect(1000, HEIGHT - 250, 150, 30),


            ]

        self.platform_images = _build_platform_images(
            self.sprites.plataforma, self.platforms
        )
    
        self.plataformas_destruidas = []

    def draw(self, screen, camera_x):

        screen.blit(self.sprites.background, (0, 0))
        self.actualizar_plataformas()

        for plat, img in zip(self.platforms[1:], self.platform_images):
            if any(dato["plataforma"] == plat for dato in self.plataformas_destruidas):
                continue

            screen.blit(img, (plat.x - camera_x, plat.y))

        road_width = self.sprites.suelo.get_width()

        start_x = -(camera_x % road_width)

        for i in range(3):
            x = start_x + i * road_width
            screen.blit(self.sprites.suelo, (x, self.platforms[0].top))

    def destruir_plataforma(self, plataforma):
        # El suelo principal nunca se destruye.
        if plataforma == self.platforms[0]:
            return False

        # Evitar destruir dos veces la misma plataforma.
        for dato in self.plataformas_destruidas:
            if dato["plataforma"] == plataforma:
                return False

        tiempo_actual = pygame.time.get_ticks()
        tiempo_reparacion = random.randint(3000, 4000)

        self.plataformas_destruidas.append({
            "plataforma": plataforma,
            "reparacion": tiempo_actual + tiempo_reparacion
        })

        return True

    def actualizar_plataformas(self):
        tiempo_actual = pygame.time.get_ticks()

        self.plataformas_destruidas = [
            dato
            for dato in self.plataformas_destruidas
            if tiempo_actual < dato["reparacion"]
        ]

    def plataformas_activas(self):
        self.actualizar_plataformas()

        destruidas = [
            dato["plataforma"]
            for dato in self.plataformas_destruidas
        ]

        return [
            plataforma
            for plataforma in self.platforms
            if plataforma not in destruidas
        ]


class SewerMap:
    def __init__(self):

        self.sprites = sewer_sprites()

        self.platforms = [pygame.Rect(-100000, HEIGHT - 150, 200000, 150),

            pygame.Rect(600, HEIGHT - 250, 150, 30),
            pygame.Rect(425, HEIGHT - 350, 150, 30),
            pygame.Rect(820, HEIGHT - 350, 150, 30),
            pygame.Rect(1000, HEIGHT - 250, 150, 30),
        ]

        self.platform_images = _build_platform_images(
            self.sprites.plataforma, self.platforms
        )

        self.plataformas_destruidas = []

    def draw(self, screen, camera_x):

        screen.blit(self.sprites.background, (0, 0))
        self.actualizar_plataformas()

        for plat, img in zip(self.platforms[1:], self.platform_images):
            if any(dato["plataforma"] == plat for dato in self.plataformas_destruidas):
                continue

            screen.blit(img, (plat.x - camera_x, plat.y))

        road_width = self.sprites.suelo.get_width()

        start_x = -(camera_x % road_width)

        for i in range(3):
            x = start_x + i * road_width
            screen.blit(self.sprites.suelo, (x, self.platforms[0].top))


    def destruir_plataforma(self, plataforma):
        # El suelo principal nunca se destruye.
        if plataforma == self.platforms[0]:
            return False

        # Evitar destruir dos veces la misma plataforma.
        for dato in self.plataformas_destruidas:
            if dato["plataforma"] == plataforma:
                return False

        tiempo_actual = pygame.time.get_ticks()
        tiempo_reparacion = random.randint(3000, 4000)

        self.plataformas_destruidas.append({
            "plataforma": plataforma,
            "reparacion": tiempo_actual + tiempo_reparacion
        })

        return True

    def actualizar_plataformas(self):
        tiempo_actual = pygame.time.get_ticks()

        self.plataformas_destruidas = [
            dato
            for dato in self.plataformas_destruidas
            if tiempo_actual < dato["reparacion"]
        ]

    def plataformas_activas(self):
        self.actualizar_plataformas()

        destruidas = [
            dato["plataforma"]
            for dato in self.plataformas_destruidas
        ]

        return [
            plataforma
            for plataforma in self.platforms
            if plataforma not in destruidas
        ]