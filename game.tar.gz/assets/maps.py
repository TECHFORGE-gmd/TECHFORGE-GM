import pygame
import os
from settings import HEIGHT
from sprites import surface_sprites, sewer_sprites

base = os.path.dirname(__file__)


def _build_platform_images(sprite, platforms):
    
    images = []
    for plat in platforms[1:]:
        images.append(
            pygame.transform.scale(sprite, (plat.width, plat.height))
        )
    return images


class SurfaceMap:
    def __init__(self):

        self.sprites = surface_sprites()

        self.platforms = [
            pygame.Rect(-100000, HEIGHT - 150, 200000, 150),

            pygame.Rect(50, HEIGHT - 250, 150, 30),
            pygame.Rect(600, HEIGHT - 250, 150, 30),
            pygame.Rect(425, HEIGHT - 350, 150, 30),

            ]

        self.platform_images = _build_platform_images(
            self.sprites.plataforma, self.platforms
        )

    def draw(self, screen, camera_x):

        screen.blit(self.sprites.background, (0, 0))
        for plat, img in zip(self.platforms[1:], self.platform_images):
            screen.blit(img, (plat.x - camera_x, plat.y))

        road_width = self.sprites.suelo.get_width()

        start_x = -(camera_x % road_width)

        for i in range(3):
            x = start_x + i * road_width
            screen.blit(self.sprites.suelo, (x, self.platforms[0].top))


class SewerMap:
    def __init__(self):

        self.sprites = sewer_sprites()

        self.platforms = [pygame.Rect(-100000, HEIGHT - 150, 200000, 150),

            pygame.Rect(50, HEIGHT - 250, 150, 30),
            pygame.Rect(600, HEIGHT - 250, 150, 30),
            pygame.Rect(425, HEIGHT - 350, 150, 30),
        ]

        self.platform_images = _build_platform_images(
            self.sprites.plataforma, self.platforms
        )

    def draw(self, screen, camera_x):

        screen.blit(self.sprites.background, (0, 0))
        for plat, img in zip(self.platforms[1:], self.platform_images):
            screen.blit(img, (plat.x - camera_x, plat.y))

        road_width = self.sprites.suelo.get_width()

        start_x = -(camera_x % road_width)

        for i in range(3):
            x = start_x + i * road_width
            screen.blit(self.sprites.suelo, (x, self.platforms[0].top))