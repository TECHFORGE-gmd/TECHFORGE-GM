from bullet import Bullet

def handle_shoot(player, bullets, mouse_pos):
    mx, my = mouse_pos

    if not player.weapon.shoot():
        return

    if player.weapon.name == "pistol":
        bullets.append(Bullet(
            player.rect.centerx,
            player.rect.centery,
            mx, my,
            player.weapon.damage
        ))

    elif player.weapon.name == "shotgun":
        for i in range(-2, 3):
            bullets.append(Bullet(
                player.rect.centerx,
                player.rect.centery,
                mx + i * 20,
                my + i * 10,
                player.weapon.damage
            ))

    elif player.weapon.name == "raygun":
        bullets.append(Bullet(
                player.rect.centerx,
                player.rect.centery,
                mx, my,
                player.weapon.damage,
                "bullet_raygun"
            ))