
from settings import ZOMBIE_SPEED, ZOMBIE_DAMAGE, BOSS_SPEED, BOSS_DAMAGE

DIFICULTADES = {
    "facil": {
        "zombie_speed_mult": 0.85,
        "zombie_health_mult": 0.75,
        "zombie_damage_mult": 0.75,
        "boss_speed_mult": 0.85,
        "boss_health_mult": 0.75,
        "boss_damage_mult": 0.75,
    },
    "normal": {
        "zombie_speed_mult": 1.0,
        "zombie_health_mult": 1.0,
        "zombie_damage_mult": 1.0,
        "boss_speed_mult": 1.0,
        "boss_health_mult": 1.0,
        "boss_damage_mult": 1.0,
    },
    "dificil": {
        "zombie_speed_mult": 1.15,
        "zombie_health_mult": 1.35,
        "zombie_damage_mult": 1.25,
        "boss_speed_mult": 1.15,
        "boss_health_mult": 1.35,
        "boss_damage_mult": 1.25,
    },
    "pesadilla": {
        "zombie_speed_mult": 1.35,
        "zombie_health_mult": 1.80,
        "zombie_damage_mult": 1.60,
        "boss_speed_mult": 1.35,
        "boss_health_mult": 1.80,
        "boss_damage_mult": 1.60,
    },
}

_dificultad_actual = "normal"


def normalizar_dificultad(nombre):
    nombre = str(nombre or "normal").strip().lower()

    equivalencias = {
        "easy": "facil",
        "facil": "facil",
        "fácil": "facil",
        "normal": "normal",
        "hard": "dificil",
        "dificil": "dificil",
        "difícil": "dificil",
        "nightmare": "pesadilla",
        "pesadilla": "pesadilla",
    }

    return equivalencias.get(nombre, "normal")


def set_difficulty(nombre):
    """Establece la dificultad para los enemigos que se creen después."""
    global _dificultad_actual
    _dificultad_actual = normalizar_dificultad(nombre)
    return _dificultad_actual


def get_difficulty():
    return _dificultad_actual


def get_difficulty_config(nombre=None):
    """Devuelve las estadísticas calculadas para zombis y jefes."""
    if nombre is None:
        nombre = _dificultad_actual

    nombre = normalizar_dificultad(nombre)
    mult = DIFICULTADES[nombre]

    # Estadísticas base del juego.
    zombie_health = 20
    boss_health = 500

    return {
        "nombre": nombre,

        "zombie_speed": max(
            1, ZOMBIE_SPEED * mult["zombie_speed_mult"]
        ),
        "zombie_health": max(
            1, round(zombie_health * mult["zombie_health_mult"])
        ),
        "zombie_damage": max(
            1, round(ZOMBIE_DAMAGE * mult["zombie_damage_mult"])
        ),

        "boss_speed": max(
            1, BOSS_SPEED * mult["boss_speed_mult"]
        ),
        "boss_health": max(
            1, round(boss_health * mult["boss_health_mult"])
        ),
        "boss_damage": max(
            1, round(BOSS_DAMAGE * mult["boss_damage_mult"])
        ),
    }
