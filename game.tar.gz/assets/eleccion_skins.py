
import asyncio
import pygame
from settings import WIDTH, HEIGHT

ANCHO_PERSONAJE = 200
ALTO_PERSONAJE = 300


async def eleccion_skin(screen):
    reloj = pygame.time.Clock()

    # Cargar las imágenes de los personajes.
    try:
        man = pygame.image.load(
            "assets/player/man.png"
        ).convert_alpha()

        girl = pygame.image.load(
            "assets/player/girl.png"
        ).convert_alpha()

        tabares = pygame.image.load(
            "assets/player/tabares.png"
        ).convert_alpha()

    except (pygame.error, FileNotFoundError) as error:
        print(f"No se pudieron cargar las imágenes: {error}")
        return None

    # Detectar el tamaño de la pantalla para adaptar los personajes.
    escala = min(
        WIDTH / 960,
        HEIGHT / 540,
        1.0
    )

    ancho = max(1, int(ANCHO_PERSONAJE * escala))
    alto = max(1, int(ALTO_PERSONAJE * escala))

    man = pygame.transform.smoothscale(man, (ancho, alto))
    girl = pygame.transform.smoothscale(girl, (ancho, alto))
    tabares = pygame.transform.smoothscale(tabares, (ancho, alto))

    # Distribuir los personajes horizontalmente.
    separacion = min(int(WIDTH * 0.27), int(220 * escala))

    centro_y = int(HEIGHT * 0.48)
    centro_x = WIDTH // 2

    rect_man = man.get_rect(
        center=(centro_x - separacion, centro_y)
    )

    rect_girl = girl.get_rect(
        center=(centro_x, centro_y)
    )

    rect_tabares = tabares.get_rect(
        center=(centro_x + separacion, centro_y)
    )

    # Fuentes adaptables.
    fuente_titulo = pygame.font.Font(
        None, max(24, int(60 * escala))
    )

    fuente = pygame.font.Font(
        None, max(20, int(40 * escala))
    )

    # Botones invisibles de selección: incluyen la imagen y su nombre.
    margen = max(10, int(15 * escala))
    zona_man = rect_man.union(
        pygame.Rect(
            rect_man.centerx - ancho // 2,
            rect_man.bottom,
            ancho,
            max(45, int(55 * escala))
        )
    ).inflate(margen * 2, margen * 2)

    zona_girl = rect_girl.union(
        pygame.Rect(
            rect_girl.centerx - ancho // 2,
            rect_girl.bottom,
            ancho,
            max(45, int(55 * escala))
        )
    ).inflate(margen * 2, margen * 2)

    zona_tabares = rect_tabares.union(
        pygame.Rect(
            rect_tabares.centerx - ancho // 2,
            rect_tabares.bottom,
            ancho,
            max(45, int(55 * escala))
        )
    ).inflate(margen * 2, margen * 2)

    personajes = [
        ("man", rect_man, zona_man, man, "CONNOR"),
        ("girl", rect_girl, zona_girl, girl, "MISHELL"),
        ("tabares", rect_tabares, zona_tabares, tabares, "TABARES"),
    ]

    while True:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                return None

            # Selección mediante mouse en PC.
            if (
                evento.type == pygame.MOUSEBUTTONDOWN
                and evento.button == 1
            ):
                for nombre, rect, zona, imagen, etiqueta in personajes:
                    if zona.collidepoint(evento.pos):
                        return nombre

            # Selección táctil en celulares y tablets.
            elif evento.type == pygame.FINGERDOWN:
                posicion = (
                    int(evento.x * screen.get_width()),
                    int(evento.y * screen.get_height())
                )

                for nombre, rect, zona, imagen, etiqueta in personajes:
                    if zona.collidepoint(posicion):
                        return nombre

            # Permitir salir con Escape en PC.
            elif (
                evento.type == pygame.KEYDOWN
                and evento.key == pygame.K_ESCAPE
            ):
                return None

        # Fondo.
        screen.fill((8, 8, 12))

        # Título.
        titulo = fuente_titulo.render(
            "SELECCIONA A TU SOBREVIVIENTE",
            True,
            (255, 255, 255)
        )

        screen.blit(
            titulo,
            titulo.get_rect(
                center=(WIDTH // 2, max(35, int(65 * escala)))
            )
        )

        # Dibujar personajes, nombres y bordes de selección.
        for nombre, rect, zona, imagen, etiqueta in personajes:
            # Resaltar la zona con un borde rojo.
            pygame.draw.rect(
                screen,
                (180, 25, 35),
                zona,
                width=max(1, int(2 * escala)),
                border_radius=max(5, int(10 * escala))
            )

            screen.blit(imagen, rect)

            texto = fuente.render(
                etiqueta,
                True,
                (255, 255, 255)
            )

            screen.blit(
                texto,
                texto.get_rect(
                    center=(
                        rect.centerx,
                        rect.bottom + max(25, int(30 * escala))
                    )
                )
            )

        # Instrucción para los jugadores.
        instruccion = pygame.font.Font(
            None, max(18, int(28 * escala))
        ).render(
            "TOCA UN PERSONAJE PARA CONTINUAR",
            True,
            (255, 65, 65)
        )

        screen.blit(
            instruccion,
            instruccion.get_rect(
                center=(
                    WIDTH // 2,
                    HEIGHT - max(20, int(25 * escala))
                )
            )
        )

        pygame.display.flip()
        reloj.tick(60)

        # Ceder el control para que Pygbag funcione correctamente.
        await asyncio.sleep(0)
