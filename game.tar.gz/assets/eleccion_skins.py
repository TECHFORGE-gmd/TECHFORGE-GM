import asyncio
import pygame
from settings import WIDTH, HEIGHT

ancho = 55
alto = 85


async def eleccion_skin(screen):
    reloj = pygame.time.Clock()

    try:
        man = pygame.image.load("assets/player/man.png").convert_alpha()
        girl = pygame.image.load("assets/player/girl.png").convert_alpha()
        tabares = pygame.image.load("assets/player/tabares.png").convert_alpha()
    except (pygame.error, FileNotFoundError) as error:
        print(f"No se pudieron cargar las imágenes de selección: {error}")
        return None

    man = pygame.transform.scale(man, (200, 300))
    girl = pygame.transform.scale(girl, (200, 300))
    tabares = pygame.transform.scale(tabares, (200, 300))

    rect_man = man.get_rect(center=(WIDTH // 2 - 220, HEIGHT // 2))
    rect_girl = girl.get_rect(center=(WIDTH // 2, HEIGHT // 2))
    rect_tabares = tabares.get_rect(center=(WIDTH // 2 + 220, HEIGHT // 2))

    fuente_titulo = pygame.font.Font(None, 60)
    fuente = pygame.font.Font(None, 40)

    while True:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                return None

            if evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
                if rect_man.collidepoint(evento.pos):
                    return "man"
                if rect_girl.collidepoint(evento.pos):
                    return "girl"
                if rect_tabares.collidepoint(evento.pos):
                    return "tabares"

        screen.fill((0, 0, 0))

        titulo = fuente_titulo.render(
            "SELECCIONA A TU SOBREVIVIENTE", True, (255, 255, 255)
        )
        screen.blit(titulo, titulo.get_rect(center=(WIDTH // 2, 80)))

        screen.blit(man, rect_man)
        screen.blit(girl, rect_girl)
        screen.blit(tabares, rect_tabares)

        texto_man = fuente.render("CONNOR", True, (255, 255, 255))
        texto_girl = fuente.render("MISHELL", True, (255, 255, 255))
        texto_tabares = fuente.render("TABARES", True, (255, 255, 255))

        screen.blit(texto_man, texto_man.get_rect(center=(WIDTH // 2 - 220, 370)))
        screen.blit(texto_girl, texto_girl.get_rect(center=(WIDTH // 2, 370)))
        screen.blit(
            texto_tabares,
            texto_tabares.get_rect(center=(WIDTH // 2 + 220, 370)),
        )

        pygame.display.flip()
        reloj.tick(60)
        await asyncio.sleep(0)
