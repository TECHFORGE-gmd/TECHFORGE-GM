import pygame


class ItemDrop:

    def __init__(self, x, y, tipo):

        self.tipo = tipo

        if tipo == "ammo":
            self.image = pygame.image.load(
                "assets/items/caja_municion.png"
            ).convert_alpha()

        elif tipo == "medkit":
            self.image = pygame.image.load(
                "assets/items/botiquin.png"
            ).convert_alpha()

        self.image = pygame.transform.scale(
            self.image,
            (45, 45)
        )

        self.rect = self.image.get_rect(
            midbottom=(x, y)
        )

    def draw(self, screen, camera_x):

        screen.blit(
            self.image,
            (
                self.rect.x - camera_x,
                self.rect.y
            )
        )

    def recoger(self, player, weapons):

        if not self.rect.colliderect(player.rect):
            return False

        if self.tipo == "ammo":

            for weapon in weapons.values():

                # Armas con munición infinita
                if weapon.ammo == -1:
                    continue

                # Recuperar cargador
                weapon.ammo = weapon.max_ammo

                # Recuperar reserva
                if weapon.reserve_ammo > 0:
                    weapon.reserve_ammo = weapon.max_ammo * 4

            return True
        
        elif self.tipo == "medkit":

            player.health = 30

            return True

        return False