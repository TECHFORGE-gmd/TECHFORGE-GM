import random
from zombies import Zombie
from boss import Boss,Boss2


class LevelManager:
    def __init__(self):
        self.level = 1
        self.setup_level()

    def setup_level(self):
        if self.level <= 4:
            self.zombies_remaining = 8
        elif self.level == 5:
            self.zombies_remaining = 1
        elif self.level <= 9:
            self.zombies_remaining = 8
        elif self.level == 10:
            self.zombies_remaining = 1
        elif self.level <= 14:
            self.zombies_remaining = 8
        elif self.level == 15:
             self.zombies_remaining = 1
        elif self.level <= 19:
            self.zombies_remaining = 8
        elif self.level == 20:
            self.zombies_remaining = 1
        elif self.level <= 24:
            self.zombies_remaining = 8
        elif self.level == 25:
            self.zombies_remaining = 1
        elif self.level <= 29:
            self.zombies_remaining = 8
        elif self.level == 30:
            self.zombies_remaining = 1
        elif self.level <= 34:
            self.zombies_remaining = 8
        elif self.level == 35:
                self.zombies_remaining = 1
        elif self.level <= 39:
            self.zombies_remaining = 8
        elif self.level == 40:
            self.zombies_remaining = 1

    def spawn_enemies(self, zombies, WIDTH, HEIGHT, plataforma, estado, dificultad=None):
        zombies.clear()

        if self.level in [5, 10,15,20]:
            return Boss(WIDTH // 2, HEIGHT // 2,dificultad)

        if self.level in [25,30,35,40]:
            return Boss2(WIDTH // 2, HEIGHT // 2,dificultad)

        for _ in range(self.zombies_remaining):
            x = random.choice([0, WIDTH])
            y = plataforma[0].top - 150
            zombies.append(Zombie(x, y, estado,dificultad))

        return None

    def next_level(self):
        self.level += 1
        self.setup_level()