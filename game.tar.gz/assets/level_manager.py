
import random

from zombies import Zombie
from boss import Boss, Boss2


class LevelManager:
    def __init__(self):
        self.level = 1
        self.setup_level()

    def setup_level(self):
        if self.level in [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100]:
            self.zombies_remaining = 1
        else:
            self.zombies_remaining = 8

    def spawn_enemies(
        self,
        zombies,
        WIDTH,
        HEIGHT,
        plataforma,
        estado,
        dificultad=None
    ):
        zombies.clear()

        # Jefes de los primeros niveles.
        if self.level in [5, 10, 15, 20, 25, 30, 35, 40, 45, 50]:
            return Boss(
                WIDTH // 2,
                HEIGHT // 2
            )

        # Jefes especiales.
        if self.level in [55, 60, 65, 70, 75, 80, 85, 90, 95, 100]:
            return Boss2(
                WIDTH // 2,
                HEIGHT // 2
            )

        # Oleadas normales.
        for _ in range(self.zombies_remaining):
            x = random.choice([0, WIDTH])
            y = plataforma[0].top - 150

            zombies.append(
                Zombie(
                    x,
                    y,
                    estado
                )
            )

        return None

    def next_level(self):
        self.level += 1
        self.setup_level()
