import pygame
import os
from settings import WIDTH, HEIGHT

ancho=55
alto=85


def _trim(surface):

    bounding = surface.get_bounding_rect()
    if bounding.width == 0 or bounding.height == 0:
        return surface
    return surface.subsurface(bounding).copy()


class Player_skin(pygame.sprite.Sprite):

    def __init__(self, x, y, skin="man"):

        super().__init__()

        self.skin = skin

        if self.skin == "man":
            ruta = "assets/player/man.png"

        elif self.skin == "girl":
            ruta = "assets/player/girl.png"

        else:
            ruta = "assets/player/tabares.png"

        imagen = pygame.image.load(ruta).convert_alpha()

        # Reducir tamaño del personaje
        self.image = pygame.transform.scale(
            imagen,
            (ancho, alto)
        )

        self.rect = self.image.get_rect(
            midbottom=(x, y)
        )

class zombiesprite:
    def __init__(self):
        base = os.path.join(os.path.dirname(__file__), "assets/zombies")

        imagen = pygame.image.load(os.path.join(base, "zombie.png")).convert_alpha()
        imagen = pygame.transform.scale(imagen, (ancho, alto))
        self.idle = _trim(imagen)

class zombie_sewer_sprite:
    def __init__(self):
        base = os.path.join(os.path.dirname(__file__), "assets/zombies")

        imagen = pygame.image.load(os.path.join(base, "zombie_sewer.png")).convert_alpha()
        imagen = pygame.transform.scale(imagen, (ancho, alto))
        self.idle = _trim(imagen)

class boss_sprite:
    def __init__(self):
        base = os.path.join(os.path.dirname(__file__), "assets/boss")

        imagen = pygame.image.load(os.path.join(base, "boss.png")).convert_alpha()
        imagen = pygame.transform.scale(imagen, (int(ancho * 2.5), int(alto * 2)))
        self.idle = _trim(imagen)

class boss2_sprite:
    def __init__(self):
        base = os.path.join(os.path.dirname(__file__), "assets/boss")

        imagen = pygame.image.load(os.path.join(base, "boss2.png")).convert_alpha()
        imagen = pygame.transform.scale(imagen, (int(ancho * 3), int(alto * 2)))
        self.idle = _trim(imagen)

class bullet_sprite:
    def __init__(self):
        base = os.path.join(os.path.dirname(__file__), "assets/bullets")

        imagen = pygame.image.load(os.path.join(base, "bullet.png")).convert_alpha()
        self.idle = pygame.transform.scale(imagen, (15, 10))

class bullet_raygun_sprite:
    def __init__(self):
            base = os.path.join(os.path.dirname(__file__), "assets/bullets")
    
            imagen = pygame.image.load(os.path.join(base, "bullet_raygun.png")).convert_alpha()
            self.idle = pygame.transform.scale(imagen, (35, 20))

class bullet2_sprite:
    def __init__(self):
        base = os.path.join(os.path.dirname(__file__), "assets/bullets")

        imagen = pygame.image.load(os.path.join(base, "bullet_boss2.png")).convert_alpha()
        self.idle = pygame.transform.scale(imagen, (80, 72))

class weapons_sprite:
    def __init__(self):
        base = os.path.join(os.path.dirname(__file__), "assets/weapons")
        imagen_p = pygame.image.load(os.path.join(base, "pistol.png")).convert_alpha()
        self.pistol = pygame.transform.scale(imagen_p, (60, 25))

        imagen_e = pygame.image.load(os.path.join(base, "shotgun.png")).convert_alpha()
        self.shotgun = pygame.transform.scale(imagen_e, (80, 25))

        imagen_r = pygame.image.load(os.path.join(base, "raygun.png")).convert_alpha()
        self.raygun = pygame.transform.scale (imagen_r,(80,25))

class surface_sprites:
    def __init__(self):

        base = os.path.join(os.path.dirname(__file__), "assets/maps")

        imagen_suelo = pygame.image.load(
            os.path.join(base, "suelo_surface.png")
        ).convert_alpha()

        self.suelo = pygame.transform.scale(
            imagen_suelo,
            (WIDTH, 150)
        )

        self.plataforma = pygame.image.load(
            os.path.join(base, "plataforma_surface.png")
        ).convert_alpha()

        self.background = pygame.image.load(os.path.join(base, "fondo_surface.jpg")).convert()
        self.background = pygame.transform.scale(self.background, (WIDTH, HEIGHT))

class sewer_sprites:
    def __init__(self):

        base = os.path.join(os.path.dirname(__file__), "assets/maps")

        imagen_suelo = pygame.image.load(
            os.path.join(base, "suelo_sewer.png")
        ).convert_alpha()

        self.suelo = pygame.transform.scale(
            imagen_suelo,
            (WIDTH, 150)
        )

        self.plataforma = pygame.image.load(
            os.path.join(base, "plataforma_sewer.png")
        ).convert_alpha()

        self.background = pygame.image.load(os.path.join(base, "fondo_sewer.jpg")).convert()
        self.background = pygame.transform.scale(self.background, (WIDTH, HEIGHT))