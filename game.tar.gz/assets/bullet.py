import pygame
import math
from sprites import bullet_sprite, bullet2_sprite, bullet_raygun_sprite


class Bullet:
    def __init__(self, x, y, target_x, target_y, damage=10, tipo="normal"):

        # ==========================================
        # SPRITE DE LA BALA
        # ==========================================

        if tipo == "boss2":
            self.sprites = bullet2_sprite()
        elif tipo == "bullet_raygun":
            self.sprites = bullet_raygun_sprite()
        else:
            self.sprites = bullet_sprite()

        # ==========================================
        # DIRECCIÓN
        # ==========================================

        dx = target_x - x
        dy = target_y - y

        dist = math.hypot(dx, dy)

        if dist != 0:
            self.dx = dx / dist
            self.dy = dy / dist
        else:
            self.dx = 0
            self.dy = 0

        # Ángulo de la bala
        self.angle = math.degrees(
            math.atan2(-self.dy, self.dx)
        )

        # ==========================================
        # IMAGEN
        # ==========================================

        self.original_image = self.sprites.idle

        self.image = pygame.transform.rotate(
            self.original_image,
            self.angle
        )

        # ==========================================
        # POSICIÓN
        # ==========================================

        self.x = float(x)
        self.y = float(y)

        self.rect = self.image.get_rect(
            center=(x, y)
        )

        # ==========================================
        # ESTADÍSTICAS
        # ==========================================

        self.speed = 10
        self.damage = damage
        
        self.penetrante = (tipo == "bullet_raygun")
        # Zombies que ya fueron golpeados por esta bala
        self.enemigos_golpeados = set()

    def update(self):

        self.x += self.dx * self.speed
        self.y += self.dy * self.speed

        self.rect.center = (
            int(self.x),
            int(self.y)
        )

    def draw(self, screen, camera_x):

        screen.blit(
            self.image,
            (
                self.rect.x - camera_x,
                self.rect.y
            )
        )