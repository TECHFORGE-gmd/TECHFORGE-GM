"""Puente entre el juego y el sitio de Exodo Z.

El juego corre dentro de un iframe en exodoz.gamer.gd. El sitio le manda por
la URL del iframe el nivel guardado y la dificultad elegida, y espera que el
juego le avise el nivel alcanzado con un postMessage.

Fuera del navegador (por ejemplo al probar en local) nada de esto hace falta,
asi que todas las funciones devuelven False o un valor por defecto sin
romper nada.
"""

ORIGEN_SITIO = "https://exodoz.gamer.gd"

DIFICULTADES = ("facil", "normal", "dificil", "extremo")

NIVEL_MAXIMO = 9999
PUNTAJE_MAXIMO = 9999999


def _ventana():
    try:
        from js import window

        return window
    except Exception:
        return None


def _desescapar(texto):
    texto = texto.replace("+", " ")

    if "%" not in texto:
        return texto

    salida = []
    i = 0

    while i < len(texto):

        caracter = texto[i]

        if caracter == "%" and i + 2 < len(texto):
            try:
                salida.append(chr(int(texto[i + 1:i + 3], 16)))
                i += 3
                continue
            except ValueError:
                pass

        salida.append(caracter)
        i += 1

    return "".join(salida)


def _origen_del_padre():
    """El origen de la pagina que tiene el juego embebido.

    En un iframe, document.referrer es la direccion de la pagina que lo
    contiene, que es justo a donde hay que mandar el mensaje. Si no se puede
    saber, se usa el sitio de siempre.
    """
    try:
        from js import document

        referencia = str(document.referrer or "")
    except Exception:
        referencia = ""

    if referencia.startswith("http"):
        partes = referencia.split("/")
        if len(partes) >= 3 and partes[2]:
            return partes[0] + "//" + partes[2]

    return ORIGEN_SITIO


def leer_parametros():
    ventana = _ventana()

    if ventana is None:
        return {}

    try:
        consulta = str(ventana.location.search or "")
    except Exception:
        return {}

    parametros = {}

    for parte in consulta.lstrip("?").split("&"):
        if not parte:
            continue
        clave, _, valor = parte.partition("=")
        parametros[_desescapar(clave)] = _desescapar(valor)

    return parametros


def nivel_de_la_url():
    try:
        nivel = int(leer_parametros().get("nivel", ""))
    except (TypeError, ValueError):
        return 1

    if nivel < 1:
        return 1

    return nivel if nivel <= NIVEL_MAXIMO else NIVEL_MAXIMO


def dificultad_de_la_url():
    valor = leer_parametros().get("dificultad", "").strip().lower()

    return valor if valor in DIFICULTADES else "normal"


def reportar(nivel, dificultad, puntaje=0, finalizada=False):
    """Manda el avance al sitio. Devuelve True si el mensaje salio.

    finalizada=True avisa que el jugador murio: el sitio marca la partida
    como terminada y esa partida entra al ranking.
    """
    ventana = _ventana()

    if ventana is None:
        return False

    try:
        nivel = int(nivel)
    except (TypeError, ValueError):
        nivel = 1

    if nivel < 1:
        nivel = 1
    elif nivel > NIVEL_MAXIMO:
        nivel = NIVEL_MAXIMO

    if dificultad not in DIFICULTADES:
        dificultad = "normal"

    try:
        puntaje = int(puntaje)
    except (TypeError, ValueError):
        puntaje = 0

    if puntaje < 0:
        puntaje = 0
    elif puntaje > PUNTAJE_MAXIMO:
        puntaje = PUNTAJE_MAXIMO

    extra = ',"finalizada":true' if finalizada else ''

    mensaje = '{"exodoz":true,"nivel":%d,"dificultad":"%s","puntaje":%d%s}' % (
        nivel,
        dificultad,
        puntaje,
        extra,
    )

    try:
        ventana.parent.postMessage(mensaje, _origen_del_padre())
    except Exception:
        return False

    return True
