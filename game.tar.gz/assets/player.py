import pygame
import math
from weapons import Weapon
from settings import WIDTH, HEIGHT, PLAYER_SPEED, GRAVITY, DAMAGE_COOLDOWN
from sprites import Player_skin


class Player:

    def __init__(self, x, y, skin="man"):

        self.sprites = Player_skin(x, y, skin)
        self.image = self.sprites.image

        self.rect = self.image.get_rect(
            midbottom=(x, y)
        )

        self.vel_y = 0
        self.speed = PLAYER_SPEED
        self.facing = 1
        self.on_ground = False

        self.health = 100

        self.weapon = Weapon("pistol", -1, -1, 10)

        self.damaged = False
        self.damage_timer = 0
        self.last_hit = 0

    def move(self, keys, mobile_controls=None):
        if mobile_controls is None:
            mobile_controls = set()

        left = keys[pygame.K_a] or "left" in mobile_controls
        right = keys[pygame.K_d] or "right" in mobile_controls
        jump = keys[pygame.K_w] or "jump" in mobile_controls

        if left and not right:
            self.rect.x -= self.speed
            self.facing = -1

        elif right and not left:
            self.rect.x += self.speed
            self.facing = 1

        if jump and self.on_ground:
            self.vel_y = -15
            self.on_ground = False

    def apply_gravity(self):
        self.vel_y += GRAVITY
        self.rect.y += self.vel_y

    def check_collision(self, platforms):

        self.on_ground = False

        for platform in platforms:

            if self.rect.colliderect(platform):

                if self.vel_y > 0:
                    self.rect.bottom = platform.top
                    self.vel_y = 0
                    self.on_ground = True

    def update(self):
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > WIDTH:
            self.rect.right = WIDTH
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > HEIGHT - 100:
            self.rect.bottom = HEIGHT - 100
            self.vel_y = 0
            self.on_ground = True

    def take_damage(self, amount):
        now = pygame.time.get_ticks()

        if now - self.last_hit > DAMAGE_COOLDOWN:
            self.health -= amount
            self.last_hit = now
            self.damaged = True
            self.damage_timer = now

    def draw(self, screen, camera_x):

        screen.blit(self.image, (self.rect.x - camera_x, self.rect.y))

        px = self.rect.centerx - camera_x
        py = self.rect.centery
        mx, my = pygame.mouse.get_pos()
        dx = mx - px
        dy = my - py
        angle = math.degrees(math.atan2(-dy, dx))
        mx, my = pygame.mouse.get_pos()
        mx += camera_x
        dx = mx - self.rect.centerx
        dy = my - self.rect.centery
        angle = math.degrees(math.atan2(-dy, dx))

        self.weapon.draw(screen, self.rect, camera_x, angle)