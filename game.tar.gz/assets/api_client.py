import asyncio
import json
import platform

API_URL = "https://exodoz.gamer.gd/api.php"

# Puente hacia el Fetch API del navegador (pygbag/WASM no incluye aiohttp).
_JS_FETCH = """
window.Fetch = window.Fetch || {};
window.Fetch.POST = function * POST (url, data) {
    var request = new Request(url, {
        headers: {'Content-Type': 'text/plain'},
        method: 'POST',
        body: data
    });
    var content = 'undefined';
    fetch(request)
      .then(function (resp) { return resp.text(); })
      .then(function (resp) { content = resp; })
      .catch(function (err) { content = JSON.stringify({success:false, message:String(err)}); });
    while (content == 'undefined') { yield; }
    yield content;
}
"""


class APIClient:
    def __init__(self, email, token, user_id=0):
        self.email = email
        self.token = token
        self.user_id = user_id
        self._js_ready = False

    def _ensure_js(self):
        if not self._js_ready:
            platform.window.eval(_JS_FETCH)
            self._js_ready = True

    async def _post(self, payload):
        try:
            self._ensure_js()
            await asyncio.sleep(0)
            text = await platform.jsiter(
                platform.window.Fetch.POST(API_URL, json.dumps(payload))
            )
            try:
                return json.loads(text)
            except Exception:
                print("Respuesta no-JSON:", str(text)[:200])
                return {"success": False}
        except Exception as e:
            print("Error de red:", e)
            return {"success": False}

    async def load_progress(self):
        payload = {
            'action': 'load_progress',
            'email': self.email,
            'token': self.token,
            'user_id': self.user_id
        }
        data = await self._post(payload)
        if data.get('success'):
            self.user_id = data.get('user_id', self.user_id)
            return data.get('partida', {})
        return None

    async def save_progress(self, nivel, puntos, zombies, jefes, dificultad):
        if self.user_id == 0:
            return False
        payload = {
            'action': 'save_progress',
            'email': self.email,
            'token': self.token,
            'user_id': self.user_id,
            'nivel': nivel,
            'puntos': puntos,
            'zombies_killed': zombies,
            'jefes_killed': jefes,
            'dificultad': dificultad
        }
        data = await self._post(payload)
        return data.get('success', False)

    async def pause_game(self):
        if self.user_id == 0:
            return False
        payload = {
            'action': 'pause_game',
            'email': self.email,
            'token': self.token,
            'user_id': self.user_id
        }
        data = await self._post(payload)
        return data.get('success', False)

    async def resume_game(self):
        if self.user_id == 0:
            return None
        payload = {
            'action': 'resume_game',
            'email': self.email,
            'token': self.token,
            'user_id': self.user_id
        }
        data = await self._post(payload)
        if data.get('success'):
            return data.get('partida', {})
        return None

    async def finish_game(self, puntos):
        if self.user_id == 0:
            return False
        payload = {
            'action': 'finish_game',
            'email': self.email,
            'token': self.token,
            'user_id': self.user_id,
            'puntos': puntos
        }
        data = await self._post(payload)
        return data.get('success', False)

    async def equip_weapon(self, id_arma):
        if self.user_id == 0:
            return False
        payload = {
            'action': 'equip_weapon',
            'email': self.email,
            'token': self.token,
            'user_id': self.user_id,
            'id_arma': id_arma
        }
        data = await self._post(payload)
        return data.get('success', False)
