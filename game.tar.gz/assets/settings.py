WIDTH = 1280
HEIGHT = 720
FPS = 60
#posicion del jugador
x = 400
y= 300
# jugador
PLAYER_SPEED = 12
GRAVITY = 0.8

# ENEMIGOS
ZOMBIE_SPEED = 5
BOSS_SPEED = 3
BULLET_DM = 7
BULLET_V = 4
JUMP_TRIGGER_HEIGHT = 40

JUMP_TRIGGER_DISTANCE = 350
JUMP_FORCE = -15
JUMP_COOLDOWN_FRAMES = 40

# DAÑO
ZOMBIE_DAMAGE = 4
BOSS_DAMAGE = 7
DAMAGE_COOLDOWN = 500

#VIDA
BOSS_HEALTH=1700
ZOMBIE_HEALTH=200

# DIFICULTAD: multiplicadores de los enemigos.
# El jugador elige la dificultad en el sitio (dificultad.php) y el sitio se la
# manda al juego por la URL del iframe. "normal" es la que estaba antes.
DIFICULTADES = {
    "facil":   {"vida": 0.7, "dano": 0.6, "velocidad": 0.75},
    "normal":  {"vida": 1.0, "dano": 1.0, "velocidad": 1.0},
    "dificil": {"vida": 1.3, "dano": 1.4, "velocidad": 1.2},
    "extremo": {"vida": 1.7, "dano": 1.8, "velocidad": 1.4},
}

