import pygame
import math
import asyncio
import random

from eleccion_skins import eleccion_skin
from settings import WIDTH, HEIGHT, FPS, x, y
from player import Player
from level_manager import LevelManager
from combat import handle_shoot
from ui import draw_ui, draw_ammo, draw_pause_button, draw_pause_menu,draw_touch_controls,draw_boss_health
from maps import SurfaceMap, SewerMap
from weapons import Weapon
from menu import draw_menu, draw_game_over
from items import ItemDrop
from boss import Boss, Boss2
import site_bridge

pygame.init()

def detectar_dispositivo_tactil():
    try:
        from js import navigator

        if int(navigator.maxTouchPoints) > 0:
            return True

        agente = str(navigator.userAgent).lower()

        return any(
            dispositivo in agente
            for dispositivo in ("android", "iphone", "ipad", "ipod")
        )

    except Exception:
        return False

def convertir_toques_en_clics(eventos):
    eventos_convertidos = []

    for evento in eventos:
        eventos_convertidos.append(evento)

        if evento.type == pygame.FINGERDOWN:
            posicion = (
                int(evento.x * WIDTH),
                int(evento.y * HEIGHT)
            )

            eventos_convertidos.append(
                pygame.event.Event(
                    pygame.MOUSEBUTTONDOWN,
                    {"pos": posicion, "button": 1}
                )
            )

    return eventos_convertidos

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Exodo Z")
clock = pygame.time.Clock()
font = pygame.font.SysFont("arial", 30)

surface_map = SurfaceMap()
sewer_map = SewerMap()
estado = "superficie"
skin_elegida = "man"
menu_bg = surface_map.sprites.background

fade_alpha = 0
fade_speed = 5
fading = False
fade_direction = 1
fade_surface = pygame.Surface((WIDTH, HEIGHT))
fade_surface.fill((0, 0, 0))

player = Player(x, y, skin_elegida)

zombies = []
bullets = []
boss_bullets = []
drops = []
boss = None
score = 0

def crear_armas():
    return {
        #bala/cargador minimo/daño/cargador maximo
        "pistol": Weapon("pistol", -1, -1, 10),
        "shotgun": Weapon("shotgun", 5, 5, 12, 32),
        "raygun": Weapon("raygun", 20, 20, 40, 100)
    }

weapons = crear_armas()
player.weapon = weapons["pistol"]

plataforma = surface_map.platforms

level_manager = LevelManager()

# El sitio manda por la URL del iframe el nivel guardado y la dificultad
# elegida. Si el juego se abre sin esos parametros, se empieza en el nivel 1
# con dificultad normal.
nivel_inicial = site_bridge.nivel_de_la_url()
dificultad_juego = site_bridge.dificultad_de_la_url()

# Avisar al sitio de que el juego arranco y a que nivel se retoma.
site_bridge.reportar(nivel_inicial, dificultad_juego, score)

boss = None
menu = True
game_over = False
paused = False
confirm_exit = False
confirm_restart = False

camera_x = 0
zombies_killed_session = 0
jefes_killed_session = 0
NIVELES_CON_DROPS = [3,6,9,12,15,18,21,24,27,30,33,36,39]
PROBABILIDAD_DROP = 0.3
MAX_DROPS_POR_NIVEL = 2
drops_nivel_actual = 0

def restart_game(nivel=1):
    global player, zombies, bullets, boss, skin_elegida
    global score, estado, camera_x
    global fading, fade_alpha, fade_direction
    global zombies_killed_session, jefes_killed_session
    global boss_bullets
    global weapons
    global drops
    global drops_nivel_actual

    score = 0
    zombies_killed_session = 0
    jefes_killed_session = 0
    drops_nivel_actual = 0

    drops.clear()
    player = Player(x, y, skin_elegida)
    weapons= crear_armas()
    player.weapon = weapons["pistol"]
    zombies.clear()
    bullets.clear()
    boss_bullets.clear()
    boss = None

    level_manager.level = nivel
    level_manager.setup_level()
    estado = "superficie"
    boss = None
    camera_x = 0
    fading = False
    fade_alpha = 0
    fade_direction = 1

async def iniciar_partida_con_personaje():

    #Pide la skin después del menú y prepara una partida nueva.
    global skin_elegida, menu, game_over, paused
    global confirm_exit, confirm_restart, boss
    seleccion = await eleccion_skin(screen)

    if seleccion not in ("man", "girl", "tabares"):
        return False

    skin_elegida = seleccion
    if skin_elegida == "man":
        print("elegiste al hombre")
    elif skin_elegida == "girl":
        print("elegiste a la mujer")
    else:
        print("elegiste a tabares")
    restart_game(nivel_inicial)

    boss = level_manager.spawn_enemies(zombies,WIDTH,HEIGHT,get_current_platforms(),estado,dificultad_juego)

    site_bridge.reportar(level_manager.level, dificultad_juego, score)

    menu = False
    game_over = False
    paused = False
    confirm_exit = False
    confirm_restart = False
    return True

def get_current_map():
    return surface_map if estado == "superficie" else sewer_map

def get_current_platforms():
    return get_current_map().plataformas_activas()

def draw_current_map():
    if estado == "superficie":
        surface_map.draw(screen, camera_x)
    else:
        sewer_map.draw(screen, camera_x)

def get_aim_angle():
    mx, my = pygame.mouse.get_pos()
    mx += camera_x
    px, py = player.rect.center
    return math.degrees(math.atan2(-(my - py), mx - px))

async def main():
    global menu, game_over, paused, confirm_exit, confirm_restart
    global player, zombies, bullets, boss, estado
    global fade_alpha, fading, fade_direction
    global score, camera_x
    global zombies_killed_session, jefes_killed_session
    global drops_nivel_actual

    touch_device = detectar_dispositivo_tactil()
    touch_fingers = {}
    mobile_controls = set()
    touch_rects = {}

    # La partida y los enemigos se preparan después de elegir una skin.

    running = True
    while running:

        clock.tick(FPS)
        await asyncio.sleep(0)

        mouse_pos = pygame.mouse.get_pos()
        keys = pygame.key.get_pressed()

        if menu:
            screen.fill((0, 0, 0))
            button = draw_menu(screen, menu_bg, WIDTH, HEIGHT, mouse_pos)
            events = convertir_toques_en_clics(pygame.event.get())

            for event in events:
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1 and button.collidepoint(event.pos):
                        await iniciar_partida_con_personaje()

            pygame.display.flip()
            continue

        events = pygame.event.get()

        if game_over:
            # Dibujar primero para que "button" exista antes de procesar el clic.
            draw_current_map()
            button = draw_game_over(screen, menu_bg, WIDTH, HEIGHT, mouse_pos)
            
            for event in  convertir_toques_en_clics(events):
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1 and button.collidepoint(event.pos):
                        # Volver al menú. La nueva skin se elige al pulsar "Empezar juego" en el menú principal

                        game_over = False
                        menu = True
                        paused = False
                        confirm_exit = False
                        confirm_restart = False

            pygame.display.flip()
            continue

        if paused:

            for event in  convertir_toques_en_clics(events):
                if event.type == pygame.QUIT:
                    confirm_exit = True
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        if confirm_exit or confirm_restart:
                            confirm_exit = False
                            confirm_restart = False
                        else:
                            paused = False
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    pause_buttons = draw_pause_menu(screen, mouse_pos, confirm_exit, confirm_restart)
                    if pause_buttons["close"].collidepoint(event.pos):
                        paused = False
                        confirm_exit = False
                        confirm_restart = False

                        continue

                    if confirm_exit or confirm_restart:
                        if pause_buttons["confirm_yes"].collidepoint(event.pos):
                            if confirm_restart:
                                restart_game()
                                paused = False
                                confirm_restart = False
                                confirm_exit = False
                            elif confirm_exit:
                                running = False

                            continue

                        elif pause_buttons["confirm_no"].collidepoint(event.pos):
                            confirm_exit = False
                            confirm_restart = False
                            continue
                    else:
                        if pause_buttons["resume"].collidepoint(event.pos):
                            paused = False
                        elif pause_buttons["restart"].collidepoint(event.pos):
                            confirm_restart = True
                            confirm_exit = False
                        elif pause_buttons["exit"].collidepoint(event.pos):
                            confirm_exit = True
                            confirm_restart = False

            mouse_pos = pygame.mouse.get_pos()
            draw_current_map()
            player.draw(screen, camera_x)
            mx, my = pygame.mouse.get_pos()
            mx += camera_x
            px, py = player.rect.center
            dx = mx - px
            dy = my - py
            angle = math.degrees(math.atan2(-dy, dx))
            player.weapon.draw(screen, player.rect, camera_x, angle)

            for zombie in zombies:
                zombie.draw(screen, camera_x)
            for drop in drops:
                drop.draw(screen, camera_x)
            for bullet in bullets:
                bullet.draw(screen, camera_x)
            for boss_bullet in boss_bullets:
                boss_bullet.draw(screen, camera_x)
            if boss:
                boss.draw(screen, camera_x)
                if isinstance(boss, Boss2):
                    boss.dibujar_superataque(screen, camera_x)
                elif isinstance(boss, Boss):
                    boss.dibujar_ataques(screen, camera_x)
                draw_boss_health(screen, boss)

            draw_ui(screen, player, font, level_manager.level, score)
            draw_ammo(screen, player, font)
            draw_pause_button(screen, mouse_pos)
            draw_pause_menu(screen, mouse_pos, confirm_exit, confirm_restart)
            pygame.display.flip()

            continue

        for event in events:

            if event.type == pygame.FINGERDOWN:
                touch_device = True

                pos = (
                    int(event.x * WIDTH),
                    int(event.y * HEIGHT)
                )

                action = None

                for nombre, rect in touch_rects.items():
                    if rect.collidepoint(pos):
                        action = nombre
                        break

                if action is not None:
                    touch_fingers[event.finger_id] = action
                    mobile_controls = set(touch_fingers.values())

                    if action == "shoot":
                        objetivo = (
                            player.rect.centerx + player.facing * 500,
                            player.rect.centery
                        )
                        handle_shoot(player, bullets, objetivo)

                    elif action == "weapon1":
                        player.weapon = weapons["pistol"]

                    elif action == "weapon2":
                        player.weapon = weapons["shotgun"]

                    elif action == "weapon3":
                        player.weapon = weapons["raygun"]

                    elif action == "reload":
                        player.weapon.start_reload()

                    elif action == "surface":
                        fading = True
                        fade_direction = 1

                    elif action == "pause":
                        paused = True
                        confirm_exit = False
                        confirm_restart = False
                        site_bridge.reportar(level_manager.level, dificultad_juego, score)

            elif event.type == pygame.FINGERUP:
                touch_fingers.pop(event.finger_id, None)
                mobile_controls = set(touch_fingers.values())

            elif event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                gear_rect = pygame.Rect(WIDTH - 74, 18, 56, 56)
                if gear_rect.collidepoint(event.pos):
                    paused = True
                    confirm_exit = False
                    confirm_restart = False
                    site_bridge.reportar(level_manager.level, dificultad_juego, score)

                    continue

                mx, my = event.pos
                mx += camera_x
                handle_shoot(player, bullets, (mx, my))
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    paused = True
                    confirm_exit = False
                    confirm_restart = False
                    site_bridge.reportar(level_manager.level, dificultad_juego, score)
                    continue

                if event.key == pygame.K_1:
                    player.weapon = weapons["pistol"]
                elif event.key == pygame.K_2:
                    player.weapon = weapons["shotgun"]
                elif event.key == pygame.K_3:
                    player.weapon = weapons["raygun"]
                elif event.key == pygame.K_r:
                    player.weapon.start_reload()
                elif event.key == pygame.K_s:

                    fading = True
                    fade_direction = 1

        if not running:
            break

        player.move(keys,mobile_controls)
        plataforma = get_current_platforms()
        player.apply_gravity()
        player.check_collision(plataforma)
        player.update()
        player.weapon.update()

        for bullet in bullets[:]:

            # Mover bala
            bullet.update()
            # Comprobar si salió de la zona visible
            world_screen_rect = pygame.Rect(camera_x,0,WIDTH,HEIGHT)

            if not world_screen_rect.colliderect(bullet.rect):
                bullets.remove(bullet)
                continue

            for zombie in zombies[:]:

                if bullet.rect.colliderect(zombie.rect):
                    # Evitar golpear varias veces al mismo zombie
                    if zombie in bullet.enemigos_golpeados:
                        continue

                    zombie.take_damage(bullet.damage)
                    bullet.enemigos_golpeados.add(zombie)

                    if zombie.health <= 0:
                        zombies.remove(zombie)
                        zombies_killed_session += 1
                        score += 50

                        if (
                            level_manager.level in NIVELES_CON_DROPS
                            and drops_nivel_actual < MAX_DROPS_POR_NIVEL
                        ):

                            if random.random() < PROBABILIDAD_DROP:
                                # Elege entre los dos
                                tipo_drop = random.choice(["ammo","medkit"])

                                drops.append(ItemDrop(zombie.rect.centerx,zombie.rect.bottom,tipo_drop))
                                drops_nivel_actual += 1

                    if not bullet.penetrante:
                        if bullet in bullets:
                            bullets.remove(bullet)
                        break

            # Si la bala ya fue eliminada
            if bullet not in bullets:
                continue
            if boss and bullet.rect.colliderect(boss.rect):
                boss.take_damage(bullet.damage)
                if bullet in bullets:
                    bullets.remove(bullet)
        for boss_bullet in boss_bullets[:]:
            boss_bullet.update()
            # Zona visible
            world_screen_rect = pygame.Rect(camera_x,0,WIDTH,HEIGHT)

            # Eliminar cuando salga de pantalla
            if not world_screen_rect.colliderect(boss_bullet.rect):
                boss_bullets.remove(boss_bullet)
                continue

            # Golpear al jugador
            if boss_bullet.rect.colliderect(player.rect):
                player.take_damage(boss_bullet.damage)
                if boss_bullet in boss_bullets:
                    boss_bullets.remove(boss_bullet)

        for zombie in zombies:
            zombie.update(player, plataforma)
            if player.rect.colliderect(zombie.rect):
                player.take_damage(zombie.damage)

        for drop in drops[:]:
            if drop.recoger(player, weapons):
                drops.remove(drop)

        if boss:
            if isinstance(boss, Boss2):
                if boss.en_superataque:
                    boss.actualizar_superataque(
                        player, plataforma, get_current_map()
                    )
                else:
                    boss.update(player, plataforma)
                    boss.actualizar_superataque(
                        player, plataforma, get_current_map()
                    )

                if not boss.en_superataque:
                    boss.shoot(player, boss_bullets)

                boss.comprobar_dano_superataque(player)

            else:
                boss.update(player, plataforma)
                boss.comprobar_dano_ataques(player)
            if boss.health <= 0:
                score += 200
                jefes_killed_session += 1

                drops.append(ItemDrop(boss.rect.centerx - 35,boss.rect.bottom,"ammo"))
                drops.append(ItemDrop(boss.rect.centerx + 35,boss.rect.bottom,"medkit"))

                boss = None

        if boss and player.rect.colliderect(boss.rect):
            player.take_damage(boss.damage)

        if not zombies and not boss:
            level_manager.next_level()
            drops_nivel_actual = 0
            boss = level_manager.spawn_enemies(zombies, WIDTH, HEIGHT, plataforma, estado, dificultad_juego)
            site_bridge.reportar(level_manager.level, dificultad_juego, score)

        if player.health <= 0:
            game_over = True
            site_bridge.reportar(level_manager.level, dificultad_juego, score)

        if fading:
            fade_alpha += (fade_speed * fade_direction)
            if fade_alpha >= 255:
                fade_alpha = 255

                estado = "alcantarilla" if estado == "superficie" else "superficie"

                fade_direction = -1

            if fade_alpha <= 0:
                fade_alpha = 0
                fading = False

        camera_x = (player.rect.x - WIDTH // 2)
        angle = get_aim_angle()
        draw_current_map()
        player.draw(screen, camera_x)
        player.weapon.draw(screen, player.rect, camera_x, angle)

        for zombie in zombies:
            zombie.draw(screen, camera_x)
        for drop in drops:
            drop.draw(screen, camera_x)
        for bullet in bullets:
            bullet.draw(screen, camera_x)
        for boss_bullet in boss_bullets:
            boss_bullet.draw(screen, camera_x)
        if boss:
            boss.draw(screen, camera_x)
            if isinstance(boss, Boss2):
                boss.dibujar_superataque(screen, camera_x)
            elif isinstance(boss, Boss):
                boss.dibujar_ataques(screen, camera_x)
            draw_boss_health(screen, boss)

        draw_ui(screen, player, font, level_manager.level, score)
        draw_ammo(screen, player, font)
        draw_pause_button(screen, pygame.mouse.get_pos())
        fade_surface.set_alpha(fade_alpha)
        screen.blit(fade_surface, (0, 0))

        if touch_device and not game_over:
            touch_rects = draw_touch_controls(screen)

        if game_over:
            button = draw_game_over(screen, menu_bg, WIDTH, HEIGHT, mouse_pos)

        pygame.display.flip()
    pygame.quit()
asyncio.run(main())
