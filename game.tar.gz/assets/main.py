import pygame
import math
import asyncio
import random
import urllib.parse

try:
    from api_client import APIClient
except Exception as api_import_error:
    APIClient = None
    print("API no disponible; el juego funcionará sin conexión:", api_import_error)

from eleccion_skins import eleccion_skin
from settings import WIDTH, HEIGHT, FPS, x, y
from player import Player
from level_manager import LevelManager
from combat import handle_shoot
from ui import draw_ui, draw_ammo, draw_pause_button, draw_pause_menu
from maps import SurfaceMap, SewerMap
from weapons import Weapon
from menu import draw_menu, draw_game_over
from items import ItemDrop
from difficulty import set_difficulty, get_difficulty, get_difficulty_config

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Exodo Z")
clock = pygame.time.Clock()
font = pygame.font.SysFont("arial", 30)

API_AUTOSAVE_INTERVAL = max(1, 30 * FPS)
api_client = None
api_load_task = None
autosave_counter = 0
last_saved_score = -1
last_saved_level = -1
api_score_finished = False


def obtener_datos_api():
    try:
        import platform
        href = str(platform.window.location.href)
        params = urllib.parse.parse_qs(urllib.parse.urlparse(href).query)
        email = params.get("email", [None])[0]
        token = params.get("token", [None])[0]
        uid_text = params.get("user_id", [None])[0]
        uid = int(uid_text) if uid_text else None
        print(f"Params URL -> token: {token}, email: {email}, uid: {uid}")
        return email, token, uid
    except Exception as exc:
        print("No se pudieron leer las credenciales de la URL:", exc)
        return None, None, None


def iniciar_api():
    global api_client, api_load_task
    if APIClient is None:
        api_client = None
        return
    email, token, uid = obtener_datos_api()
    if email and token and uid:
        try:
            api_client = APIClient(email, token, uid)
            api_load_task = asyncio.create_task(api_client.load_progress())
            print("API preparada; intentando cargar progreso en segundo plano.")
        except Exception as exc:
            api_client = None
            api_load_task = None
            print("No se pudo iniciar la API:", exc)
    else:
        api_client = None
        api_load_task = None
        print("Sin credenciales API: Éxodo Z funcionará normalmente sin conexión.")


def programar_guardado():
    global last_saved_score, last_saved_level
    if api_client is None:
        return
    try:
        asyncio.create_task(api_client.save_progress(
            nivel=level_manager.level,
            puntos=score,
            zombies=zombies_killed_session,
            jefes=jefes_killed_session,
            dificultad=get_difficulty(),
        ))
        last_saved_score = score
        last_saved_level = level_manager.level
        print(f"Guardando: nivel={level_manager.level}, puntos={score}, zombies={zombies_killed_session}, jefes={jefes_killed_session}")
    except Exception as exc:
        print("No se pudo programar el guardado:", exc)


async def aplicar_progreso_guardado():
    global score, api_load_task, autosave_counter
    if api_load_task is None:
        return False
    if not api_load_task.done():
        return False
    try:
        partida = api_load_task.result()
    except Exception as exc:
        print("Error al recuperar el progreso:", exc)
        api_load_task = None
        return False
    api_load_task = None
    if not isinstance(partida, dict):
        return False
    try:
        nivel_guardado = max(1, int(partida.get("nivel", 1)))
        puntos_guardados = max(0, int(partida.get("puntos", 0)))
        level_manager.level = nivel_guardado
        level_manager.setup_level()
        score = puntos_guardados
        autosave_counter = 0
        print(f"Progreso recuperado: nivel {nivel_guardado}, puntos {puntos_guardados}")
        return True
    except Exception as exc:
        print("Los datos guardados no se pudieron aplicar:", exc)
        level_manager.level = 1
        level_manager.setup_level()
        score = 0
        return False


surface_map = SurfaceMap()
sewer_map = SewerMap()
estado = "superficie"
skin_elegida = "man"
menu_bg = surface_map.sprites.background
fade_alpha = 0
fade_speed = 5
fading = False
fade_direction = 1
fade_surface = pygame.Surface((WIDTH, HEIGHT))
fade_surface.fill((0, 0, 0))
player = Player(x, y, skin_elegida)
zombies = []
bullets = []
boss_bullets = []
drops = []
boss = None
score = 0


def crear_armas():
    return {
        "pistol": Weapon("pistol", -1, -1, 10),
        "shotgun": Weapon("shotgun", 8, 8, 25, 32),
        "raygun": Weapon("raygun", 5, 5, 50, 20),
    }


weapons = crear_armas()
player.weapon = weapons["pistol"]
plataforma = surface_map.platforms
level_manager = LevelManager()
menu = True
game_over = False
paused = False
confirm_exit = False
confirm_restart = False
camera_x = 0
zombies_killed_session = 0
jefes_killed_session = 0
NIVELES_CON_DROPS = [3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 39]
PROBABILIDAD_DROP = 0.3
MAX_DROPS_POR_NIVEL = 2
drops_nivel_actual = 0


def restart_game():
    global player, zombies, bullets, boss, score, estado, camera_x
    global fading, fade_alpha, fade_direction
    global zombies_killed_session, jefes_killed_session, boss_bullets
    global weapons, drops, drops_nivel_actual, autosave_counter, api_score_finished

    score = 0
    zombies_killed_session = 0
    jefes_killed_session = 0
    drops.clear()
    drops_nivel_actual = 0
    player = Player(x, y, skin_elegida)
    weapons = crear_armas()
    player.weapon = weapons["pistol"]
    zombies.clear()
    bullets.clear()
    boss_bullets.clear()
    boss = None
    level_manager.level = 1
    level_manager.setup_level()
    estado = "superficie"
    camera_x = 0
    fading = False
    fade_alpha = 0
    fade_direction = 1
    autosave_counter = 0
    api_score_finished = False


async def iniciar_partida_con_personaje():
    global skin_elegida, menu, game_over, paused
    global confirm_exit, confirm_restart, boss, autosave_counter

    seleccion = await eleccion_skin(screen)
    if seleccion not in ("man", "girl", "tabares"):
        return False

    skin_elegida = seleccion
    print("Elegiste:", skin_elegida)
    restart_game()

    progreso_cargado = await aplicar_progreso_guardado()
    boss = level_manager.spawn_enemies(
        zombies, WIDTH, HEIGHT, get_current_platforms(), estado
    )
    menu = False
    game_over = False
    paused = False
    confirm_exit = False
    confirm_restart = False
    autosave_counter = 0
    if progreso_cargado:
        print("Se inició la partida con el progreso recuperado.")
    return True


def get_current_platforms():
    return surface_map.platforms if estado == "superficie" else sewer_map.platforms


def draw_current_map():
    if estado == "superficie":
        surface_map.draw(screen, camera_x)
    else:
        sewer_map.draw(screen, camera_x)


def get_aim_angle():
    mx, my = pygame.mouse.get_pos()
    mx += camera_x
    px, py = player.rect.center
    return math.degrees(math.atan2(-(my - py), mx - px))


async def main():
    global menu, game_over, paused, confirm_exit, confirm_restart
    global player, zombies, bullets, boss, estado
    global fade_alpha, fading, fade_direction, score, camera_x
    global zombies_killed_session, jefes_killed_session, drops_nivel_actual
    global autosave_counter, api_score_finished

    iniciar_api()
    running = True

    while running:
        clock.tick(FPS)
        await asyncio.sleep(0)
        mouse_pos = pygame.mouse.get_pos()
        keys = pygame.key.get_pressed()

        if menu:
            screen.fill((0, 0, 0))
            button = draw_menu(screen, menu_bg, WIDTH, HEIGHT, mouse_pos)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if button.collidepoint(event.pos):
                        await iniciar_partida_con_personaje()
            pygame.display.flip()
            continue

        events = pygame.event.get()

        if game_over:
            draw_current_map()
            button = draw_game_over(screen, menu_bg, WIDTH, HEIGHT, mouse_pos)
            for event in events:
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if button.collidepoint(event.pos):
                        game_over = False
                        menu = True
                        paused = False
                        confirm_exit = False
                        confirm_restart = False
            pygame.display.flip()
            continue

        if paused:
            for event in events:
                if event.type == pygame.QUIT:
                    confirm_exit = True
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    if confirm_exit or confirm_restart:
                        confirm_exit = False
                        confirm_restart = False
                    else:
                        paused = False
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    pause_buttons = draw_pause_menu(screen, mouse_pos, confirm_exit, confirm_restart)
                    if pause_buttons["close"].collidepoint(event.pos):
                        paused = False
                        confirm_exit = False
                        confirm_restart = False
                        continue
                    if confirm_exit or confirm_restart:
                        if pause_buttons["confirm_yes"].collidepoint(event.pos):
                            if confirm_restart:
                                restart_game()
                                paused = False
                                confirm_restart = False
                                confirm_exit = False
                            elif confirm_exit:
                                running = False
                            continue
                        elif pause_buttons["confirm_no"].collidepoint(event.pos):
                            confirm_exit = False
                            confirm_restart = False
                            continue
                    else:
                        if pause_buttons["resume"].collidepoint(event.pos):
                            paused = False
                        elif pause_buttons["restart"].collidepoint(event.pos):
                            confirm_restart = True
                            confirm_exit = False
                        elif pause_buttons["exit"].collidepoint(event.pos):
                            confirm_exit = True
                            confirm_restart = False

            mouse_pos = pygame.mouse.get_pos()
            draw_current_map()
            player.draw(screen, camera_x)
            mx, my = pygame.mouse.get_pos()
            mx += camera_x
            px, py = player.rect.center
            angle = math.degrees(math.atan2(-(my - py), mx - px))
            player.weapon.draw(screen, player.rect, camera_x, angle)
            for zombie in zombies:
                zombie.draw(screen, camera_x)
            for drop in drops:
                drop.draw(screen, camera_x)
            for bullet in bullets:
                bullet.draw(screen, camera_x)
            for boss_bullet in boss_bullets:
                boss_bullet.draw(screen, camera_x)
            if boss:
                boss.draw(screen, camera_x)
            draw_ui(screen, player, font, level_manager.level, score)
            draw_ammo(screen, player, font)
            draw_pause_button(screen, mouse_pos)
            draw_pause_menu(screen, mouse_pos, confirm_exit, confirm_restart)
            pygame.display.flip()
            continue

        for event in events:
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                gear_rect = pygame.Rect(WIDTH - 74, 18, 56, 56)
                if gear_rect.collidepoint(event.pos):
                    paused = True
                    confirm_exit = False
                    confirm_restart = False
                    continue
                mx, my = event.pos
                mx += camera_x
                handle_shoot(player, bullets, (mx, my))
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    paused = True
                    confirm_exit = False
                    confirm_restart = False
                elif event.key == pygame.K_1:
                    player.weapon = weapons["pistol"]
                elif event.key == pygame.K_2:
                    player.weapon = weapons["shotgun"]
                elif event.key == pygame.K_3:
                    player.weapon = weapons["raygun"]
                elif event.key == pygame.K_r:
                    player.weapon.start_reload()
                elif event.key == pygame.K_s:
                    fading = True
                    fade_direction = 1

        if not running:
            break

        player.move(keys)
        plataforma = get_current_platforms()
        player.apply_gravity()
        player.check_collision(plataforma)
        player.update()
        player.weapon.update()

        for bullet in bullets[:]:
            bullet.update()
            world_screen_rect = pygame.Rect(camera_x, 0, WIDTH, HEIGHT)
            if not world_screen_rect.colliderect(bullet.rect):
                bullets.remove(bullet)
                continue
            for zombie in zombies[:]:
                if bullet.rect.colliderect(zombie.rect):
                    if zombie in bullet.enemigos_golpeados:
                        continue
                    zombie.take_damage(bullet.damage)
                    bullet.enemigos_golpeados.add(zombie)
                    if zombie.health <= 0:
                        zombies.remove(zombie)
                        zombies_killed_session += 1
                        score += 50
                        if (level_manager.level in NIVELES_CON_DROPS
                                and drops_nivel_actual < MAX_DROPS_POR_NIVEL):
                            if random.random() < PROBABILIDAD_DROP:
                                tipo_drop = random.choice(["ammo", "medkit"])
                                drops.append(ItemDrop(
                                    zombie.rect.centerx, zombie.rect.bottom, tipo_drop
                                ))
                                drops_nivel_actual += 1
                    if not bullet.penetrante:
                        if bullet in bullets:
                            bullets.remove(bullet)
                        break
            if bullet not in bullets:
                continue
            if boss and bullet.rect.colliderect(boss.rect):
                boss.take_damage(bullet.damage)
                if bullet in bullets:
                    bullets.remove(bullet)

        for boss_bullet in boss_bullets[:]:
            boss_bullet.update()
            world_screen_rect = pygame.Rect(camera_x, 0, WIDTH, HEIGHT)
            if not world_screen_rect.colliderect(boss_bullet.rect):
                boss_bullets.remove(boss_bullet)
                continue
            if boss_bullet.rect.colliderect(player.rect):
                player.take_damage(boss_bullet.damage)
                if boss_bullet in boss_bullets:
                    boss_bullets.remove(boss_bullet)

        for zombie in zombies:
            zombie.update(player, plataforma)
            if player.rect.colliderect(zombie.rect):
                player.take_damage(zombie.damage)

        for drop in drops[:]:
            if drop.recoger(player, weapons):
                drops.remove(drop)

        if boss:
            boss.update(player, plataforma)
            if hasattr(boss, "shoot"):
                boss.shoot(player, boss_bullets)
            if boss.health <= 0:
                score += 200
                jefes_killed_session += 1
                drops.append(ItemDrop(boss.rect.centerx - 35, boss.rect.bottom, "ammo"))
                drops.append(ItemDrop(boss.rect.centerx + 35, boss.rect.bottom, "medkit"))
                boss = None

        if boss and player.rect.colliderect(boss.rect):
            player.take_damage(boss.damage)

        if not zombies and not boss:
            level_manager.next_level()
            drops_nivel_actual = 0
            boss = level_manager.spawn_enemies(
                zombies, WIDTH, HEIGHT, plataforma, estado
            )

        if player.health <= 0 and not game_over:
            game_over = True
            if api_client is not None and not api_score_finished:
                try:
                    asyncio.create_task(api_client.finish_game(score))
                    api_score_finished = True
                except Exception as exc:
                    print("No se pudo registrar la puntuación:", exc)

        # Autoguardado
        autosave_counter += 1
        if autosave_counter >= API_AUTOSAVE_INTERVAL:
            autosave_counter = 0
            if (score != last_saved_score or level_manager.level != last_saved_level):
                programar_guardado()

        if fading:
            fade_alpha += fade_speed * fade_direction
            if fade_alpha >= 255:
                fade_alpha = 255
                estado = "alcantarilla" if estado == "superficie" else "superficie"
                fade_direction = -1
            if fade_alpha <= 0:
                fade_alpha = 0
                fading = False

        camera_x = player.rect.x - WIDTH // 2
        angle = get_aim_angle()
        draw_current_map()
        player.draw(screen, camera_x)
        player.weapon.draw(screen, player.rect, camera_x, angle)
        for zombie in zombies:
            zombie.draw(screen, camera_x)
        for drop in drops:
            drop.draw(screen, camera_x)
        for bullet in bullets:
            bullet.draw(screen, camera_x)
        for boss_bullet in boss_bullets:
            boss_bullet.draw(screen, camera_x)
        if boss:
            boss.draw(screen, camera_x)
        draw_ui(screen, player, font, level_manager.level, score)
        draw_ammo(screen, player, font)
        draw_pause_button(screen, pygame.mouse.get_pos())
        fade_surface.set_alpha(fade_alpha)
        screen.blit(fade_surface, (0, 0))
        if game_over:
            draw_game_over(screen, menu_bg, WIDTH, HEIGHT, mouse_pos)
        pygame.display.flip()

    if api_client is not None:
        try:
            await asyncio.wait_for(
                api_client.save_progress(
                    nivel=level_manager.level,
                    puntos=score,
                    zombies=zombies_killed_session,
                    jefes=jefes_killed_session,
                    dificultad=get_difficulty(),
                ),
                timeout=2.0
            )
        except Exception:
            pass
    pygame.quit()


asyncio.run(main())