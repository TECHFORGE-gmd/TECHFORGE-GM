import pygame
import random

from settings import (
    GRAVITY,
    JUMP_COOLDOWN_FRAMES,
    BOSS_DAMAGE,
    BOSS_HEALTH,
    BOSS_SPEED,
    JUMP_FORCE,
    JUMP_TRIGGER_DISTANCE,
    JUMP_TRIGGER_HEIGHT,
    HEIGHT,
    WIDTH,
    BULLET_DM,
    BULLET_V,
    )

from bullet import Bullet
from sprites import boss_sprite, boss2_sprite,bullet2_sprite


class Boss:

    def __init__(self, x, y, vida=1.0, dano=1.0, velocidad=1.0):

        # SPRITE
        self.sprite = boss_sprite()
        self.image = self.sprite.idle

        self.rect = self.image.get_rect(topleft=(x, y))

        # Hitbox 
        self.rect.inflate_ip(-15, -15)

        #estadistica
        self.health = max(1, int(round(BOSS_HEALTH * vida)))
        self.damage = max(1, int(round(BOSS_DAMAGE * dano)))
        self.speed = max(1, int(round(BOSS_SPEED * velocidad)))
        self.max_health = self.health

        # FÍSICA
        self.vel_y = 0
        self.on_ground = False

        # Plataforma sobre la que está parado
        self.plataforma_actual = None

        # BAJAR DE PLATAFORMA
        self.bajando_plataforma = False

        # SALTO
        self.jump_cooldown = 0

        # DAÑO
        self.damaged = False
        self.damage_timer = 0

        # SUPERATAQUE 1: salto sísmico
        ahora = pygame.time.get_ticks()
        self.siguiente_salto_sismico = ahora + 5000
        self.estado_ataque = None
        self.altura_salto_sismico = -20
        self.ataque_anterior_en_suelo = True

        # Escombros y ondas de choque
        self.escombros = []
        self.ondas_choque = []

        # SUPERATAQUE 2: salto extremo
        self.siguiente_super_salto = ahora + random.randint(12000, 18000)
        self.destino_super_salto = None
        self.direccion_onda = 0

        # Evitar daño continuo en cada fotograma
        self.ultimo_dano_ataque = 0

        # Los saltos del jefe aterrizan siempre en el suelo principal.
        self.salto_hasta_suelo = False

        # Daño y velocidad de las ondas de choque.
        self.velocidad_onda = 12
        self.dano_escombros = 20
        self.dano_onda = 25

    def crear_escombros(self):
        """Crea escombros que caen desde arriba en posiciones aleatorias."""
        ahora = pygame.time.get_ticks()

        for _ in range(random.randint(7, 12)):
            x = self.rect.centerx + random.randint(-WIDTH // 2, WIDTH // 2)

            self.escombros.append({
                "x": x,
                "y": -random.randint(20, 180),
                "velocidad": random.randint(5, 10),
                "rect": pygame.Rect(x, -30, 24, 30),
                "aviso": ahora + 500
            })

    def actualizar_escombros(self):
        ahora = pygame.time.get_ticks()

        for escombro in self.escombros[:]:
            if ahora >= escombro["aviso"]:
                escombro["y"] += escombro["velocidad"]
                escombro["rect"].x = int(escombro["x"])
                escombro["rect"].y = int(escombro["y"])

            if escombro["y"] > HEIGHT:
                self.escombros.remove(escombro)

    def dibujar_ataques(self, screen, camera_x):
        ahora = pygame.time.get_ticks()

        # Advertencias y escombros
        for escombro in self.escombros:
            x_pantalla = int(escombro["x"] - camera_x)

            if ahora < escombro["aviso"]:
                aviso = pygame.Surface((34, HEIGHT), pygame.SRCALPHA)
                aviso.fill((255, 0, 0, 45))
                screen.blit(aviso, (x_pantalla - 17, 0))

                pygame.draw.line(
                    screen,
                    (255, 50, 50),
                    (x_pantalla, 0),
                    (x_pantalla, HEIGHT),
                    2
                )
            else:
                rect = pygame.Rect(
                    x_pantalla,
                    int(escombro["y"]),
                    24,
                    30
                )
                pygame.draw.rect(screen, (120, 100, 85), rect)
                pygame.draw.rect(screen, (50, 40, 35), rect, 2)

        # Ondas de choque a ras del suelo
        for onda in self.ondas_choque:
            rect = pygame.Rect(
                int(onda["x"] - camera_x),
                HEIGHT - 160,
                70,
                25
            )
            pygame.draw.rect(screen, (255, 60, 20), rect)
            pygame.draw.rect(screen, (255, 180, 40), rect, 2)

    def update(self, player, plataformas):

        # MOVIMIENTO HORIZONTAL
        speed = self.speed
        if player.rect.centerx > self.rect.centerx:
            self.rect.x += speed

        elif player.rect.centerx < self.rect.centerx:
            self.rect.x -= speed

        # DECIDIR SI DEBE BAJAR
        if (
            self.on_ground
            and
            not self.bajando_plataforma
            and
            self.plataforma_actual is not None
        ):

            if self.jugador_debajo(player):

                self.bajando_plataforma = True

                self.plataforma_actual = self.plataforma_actual

        # GRAVEDAD
        self.vel_y += GRAVITY
        self.rect.y += self.vel_y
        self.on_ground = False

        # COLISIONES CON PLATAFORMAS
        for platform in plataformas:

            # Durante un salto del jefe, ignorar todas las plataformas elevadas.
            if self.salto_hasta_suelo and platform != plataformas[0]:
                continue

            if not self.rect.colliderect(platform):
                continue

            if not self.rect.colliderect(platform):
                continue

            # Solo colisionamos con plataformas cuando caemos
            if self.vel_y <= 0:
                continue

            # ESTÁ BAJANDO
            if self.bajando_plataforma:

                # IGNORAR LA PLATAFORMA DE LA QUE ESTÁ BAJANDO
                if platform == self.plataforma_actual:
                    continue

                # Aterrizar sobre otra plataforma
                self.rect.bottom = platform.top

                self.vel_y = 0

                self.on_ground = True

                self.bajando_plataforma = False

                self.plataforma_actual = platform

                break


            # =================================================
            # COMPORTAMIENTO NORMAL
            # =================================================

            else:

                self.rect.bottom = platform.top

                self.vel_y = 0

                self.on_ground = True

                self.plataforma_actual = platform

                break


        # =====================================================
        # SUELO
        # =====================================================

        if self.rect.bottom >= HEIGHT - 100:

            self.rect.bottom = HEIGHT - 100

            self.vel_y = 0

            self.on_ground = True

            self.salto_hasta_suelo = False

            self.bajando_plataforma = False

            self.plataforma_actual = None


        # =====================================================
        # COOLDOWN
        # =====================================================

        if self.jump_cooldown > 0:
            self.jump_cooldown -= 1


        # =====================================================
        # SALTO
        # =====================================================

        if (
            self.on_ground
            and
            not self.bajando_plataforma
            and
            self.jump_cooldown == 0
        ):

            height_diff = (
                self.rect.bottom -
                player.rect.bottom
            )

            horizontal_diff = abs(
                player.rect.centerx -
                self.rect.centerx
            )

            if (
                height_diff > JUMP_TRIGGER_HEIGHT
                and
                horizontal_diff < JUMP_TRIGGER_DISTANCE
            ):

                self.vel_y = JUMP_FORCE
                self.salto_hasta_suelo = True

                self.on_ground = False

                self.plataforma_actual = None

                self.jump_cooldown = (
                    JUMP_COOLDOWN_FRAMES +
                    random.randint(0, 20)
                )

        ahora = pygame.time.get_ticks()

       
        # Actualizar escombros y ondas de choque.
        self.actualizar_escombros()

        # Mover las ondas horizontalmente.
        for onda in self.ondas_choque[:]:
            onda["x"] += self.velocidad_onda * onda["direccion"]

            # Eliminar ondas que ya están lejos del jugador.
            if abs(onda["x"] - player.rect.centerx) > WIDTH * 2:
                self.ondas_choque.remove(onda)

        ahora = pygame.time.get_ticks()

        # Detectar cuando termina el salto sísmico.
        if (
            self.estado_ataque == "salto_sismico"
            and not self.ataque_anterior_en_suelo
            and self.on_ground
        ):
            self.crear_escombros()
            self.estado_ataque = None
            self.siguiente_salto_sismico = ahora + 5000

        # Detectar cuando termina el super salto.
        elif (
            self.estado_ataque == "super_salto"
            and not self.ataque_anterior_en_suelo
            and self.on_ground
        ):
            # Dos ondas salen en direcciones opuestas.
            self.ondas_choque.append({
                "x": self.rect.centerx,
                "direccion": -1
            })
            self.ondas_choque.append({
                "x": self.rect.centerx,
                "direccion": 1
            })

            self.estado_ataque = None
            self.siguiente_super_salto = ahora + random.randint(12000, 18000)

        # Iniciar un ataque sísmico cada 5 segundos.
        if (
            self.estado_ataque is None
            and self.on_ground
            and ahora >= self.siguiente_salto_sismico
        ):
            self.estado_ataque = "salto_sismico"
            self.vel_y = self.altura_salto_sismico
            self.on_ground = False
            self.plataforma_actual = None
            self.salto_hasta_suelo = True

        # Iniciar el super salto cuando corresponda.
        elif (
            self.estado_ataque is None
            and self.on_ground
            and ahora >= self.siguiente_super_salto
        ):
            self.estado_ataque = "super_salto"
            self.vel_y = -30
            self.on_ground = False
            self.plataforma_actual = None
            self.salto_hasta_suelo = True

        self.ataque_anterior_en_suelo = self.on_ground



    # =========================================================
    # DETECTAR JUGADOR DEBAJO
    # =========================================================

    def jugador_debajo(self, player):

        # El centro del jugador está debajo
        diferencia_vertical = (
            player.rect.centery -
            self.rect.centery
        )

        abajo = diferencia_vertical > 20


        # Distancia horizontal
        diferencia_horizontal = abs(
            player.rect.centerx -
            self.rect.centerx
        )

        horizontal = diferencia_horizontal < 150


        return abajo and horizontal

    def comprobar_dano_ataques(self, player):
        ahora = pygame.time.get_ticks()

        # Evitar daño continuo en cada fotograma.
        if ahora - self.ultimo_dano_ataque < 700:
            return

        # Comprobar escombros que ya han empezado a caer.
        for escombro in self.escombros:
            if ahora >= escombro["aviso"]:
                if escombro["rect"].colliderect(player.rect):
                    player.take_damage(self.dano_escombros)
                    self.ultimo_dano_ataque = ahora
                    return

        # Comprobar ondas de choque a ras del suelo.
        for onda in self.ondas_choque:
            rect_onda = pygame.Rect(
                int(onda["x"] - 35),
                HEIGHT - 125,
                70,
                25
            )

            if rect_onda.colliderect(player.rect):
                player.take_damage(self.dano_onda)
                self.ultimo_dano_ataque = ahora
                return
            
    #recibe daño        

    def take_damage(self, amount):

        self.health -= amount

        self.damaged = True

        self.damage_timer = pygame.time.get_ticks()


    # =========================================================
    # DIBUJAR
    # =========================================================

    def draw(self, screen, camera_x):

        image = self.sprite.idle.copy()

        if self.damaged:

            if (
                pygame.time.get_ticks() -
                self.damage_timer
                < 100
            ):

                tint = pygame.Surface(
                    image.get_size()
                )

                tint.fill((255, 0, 200))

                image.blit(
                    tint,
                    (0, 0),
                    special_flags=pygame.BLEND_RGB_ADD
                )

            else:

                self.damaged = False

        screen.blit(
            image,
            (
                self.rect.x - camera_x,
                self.rect.y
            )
        )
class Boss2:

    def __init__(self, x, y, vida=1.0, dano=1.0, velocidad=1.0):

        self.sprite = boss2_sprite()
        self.image = self.sprite.idle
        
        # Sprite gigante preparado una sola vez para evitar ralentizaciones.
        self.sprite_cohete_gigante = pygame.transform.scale(
            bullet2_sprite().idle,
            (200, 140)
        )

        self.sprite_cohete_gigante_izquierda = pygame.transform.flip(
            self.sprite_cohete_gigante,
            True,
            False
        )

        self.rect = self.image.get_rect(topleft=(x, y))


        self.rect.inflate_ip(-15, -15)

        self.health = max(1, int(round(BOSS_HEALTH * vida)))
        self.damage = max(1, int(round(BOSS_DAMAGE * dano)))
        self.speed = max(1, int(round(BOSS_SPEED * velocidad)))
        self.max_health = self.health


        self.vel_y = 0
        self.on_ground = False

        self.plataforma_actual = None

        self.bajando_plataforma = False

        self.jump_cooldown = 0

        self.damaged = False
        self.damage_timer = 0
        self.shoot_delay = 1500
        self.last_shot = 0

                # SUPERATAQUE: tres cohetes gigantes
        ahora = pygame.time.get_ticks()
        self.en_superataque = False
        self.estado_superataque = "normal"
        self.siguiente_superataque = ahora + random.randint(12000, 20000)

        self.cohetes_gigantes = []
        self.cohete_actual = None
        self.disparos_gigantes = 0
        self.aviso_inicio = 0
        self.velocidad_cohete_gigante = 50

        self.plataforma_regreso = None
        self.ultimo_dano_gigante = 0

    def iniciar_superataque(self):
        ahora = pygame.time.get_ticks()

        self.en_superataque = True
        self.estado_superataque = "subiendo"
        self.disparos_gigantes = 0
        self.cohete_actual = None
        self.cohetes_gigantes.clear()

        # El jefe sale por arriba de la pantalla.
        self.plataforma_actual = None
        self.on_ground = False
        self.vel_y = -24

        self.siguiente_superataque = ahora + random.randint(12000, 20000)

    def actualizar_superataque(self, player, plataformas, mapa=None):
        ahora = pygame.time.get_ticks()

        # Esperar hasta que llegue el momento del superataque.
        if not self.en_superataque:
            if self.on_ground and ahora >= self.siguiente_superataque:
                self.iniciar_superataque()
            return

        # 1. El jefe sube y sale de la pantalla.
        if self.estado_superataque == "subiendo":
            self.rect.y -= 24

            if self.rect.bottom < 0:
                self.estado_superataque = "preparando"
                self.aviso_inicio = ahora
                self.cohete_actual = None

        # 2. Preparar la siguiente trayectoria.
        elif self.estado_superataque == "preparando":
            # Pequeña pausa entre disparos.
            if ahora - self.aviso_inicio < 350:
                return

            # Elegir solamente plataformas elevadas.
            opciones = [
                p for p in plataformas
                if p.width < 100000
                and p.height < 150
                and p.top < HEIGHT - 100
            ]

            if not opciones:
                self.aviso_inicio = ahora
                return

            plataforma = random.choice(opciones)

            # Elegir la altura del proyectil.
            altura = random.choice([
                plataforma.top - 50,
                plataforma.top - 130,
                HEIGHT - 160
            ])

            # Límites visibles aproximados de la cámara en coordenadas del mundo.
            borde_izquierdo = player.rect.x - WIDTH // 2

            # Elegir desde qué extremo saldrá el proyectil.
            direccion = random.choice([-1, 1])

            if direccion == 1:
                inicio_x = borde_izquierdo - 150
            else:
                inicio_x = borde_izquierdo + WIDTH

            self.cohete_actual = {
                "rect": pygame.Rect(
                    inicio_x,
                    altura - 35,
                    150,
                    70
                ),
                "plataforma": plataforma,
                "direccion": direccion,
                "distancia": 0,
                "plataforma_destruida": False
            }

            # ¡Primero mostrar el aviso! Todavía no se mueve el proyectil.
            self.aviso_inicio = ahora
            self.estado_superataque = "aviso"

        # 3. Dar tiempo al jugador para reaccionar.
        elif self.estado_superataque == "aviso":
            if ahora - self.aviso_inicio >= 550:
                self.estado_superataque = "disparando"

        # 4. Lanzar el proyectil horizontalmente.
        elif self.estado_superataque == "disparando":
            cohete = self.cohete_actual

            if cohete is None:
                self.estado_superataque = "preparando"
                self.aviso_inicio = ahora
                return

            
            desplazamiento = self.velocidad_cohete_gigante

            cohete["rect"].x += (
                desplazamiento * cohete["direccion"]
            )

            cohete["distancia"] += desplazamiento

            # Destruir como máximo una plataforma por cohete.
            # El suelo principal nunca se selecciona como objetivo.
            objetivo = cohete["plataforma"]

            if (
                mapa is not None
                and not cohete["plataforma_destruida"]
                and objetivo != mapa.platforms[0]
            ):
                cohete_rect = cohete["rect"]

                cruzo_plataforma = (
                    cohete_rect.right >= objetivo.left
                    and cohete_rect.left <= objetivo.right
                )

                if cruzo_plataforma:
                    destruida = mapa.destruir_plataforma(objetivo)

                    if destruida:
                        cohete["plataforma_destruida"] = True


            # Terminar cuando haya atravesado toda la pantalla.
            if cohete["distancia"] >= WIDTH + cohete["rect"].width:
                self.disparos_gigantes += 1
                self.cohete_actual = None

                if self.disparos_gigantes >= 3:
                    # El jefe vuelve desde arriba y desciende.
                    self.estado_superataque = "bajando"
                    self.rect.x = player.rect.centerx - self.rect.width // 2
                    self.rect.y = -self.rect.height
                    self.vel_y = 0
                    self.on_ground = False
                    self.plataforma_actual = None
                else:
                    # Preparar el siguiente aviso y disparo.
                    self.estado_superataque = "preparando"
                    self.aviso_inicio = ahora

        # 5. El jefe vuelve a aterrizar.
        elif self.estado_superataque == "bajando":
            self.vel_y += GRAVITY
            self.rect.y += self.vel_y
            self.on_ground = False

            for plataforma in plataformas:
                if (
                    self.vel_y > 0
                    and self.rect.colliderect(plataforma)
                    and self.rect.bottom - self.vel_y <= plataforma.top + 10
                ):
                    self.rect.bottom = plataforma.top
                    self.vel_y = 0
                    self.on_ground = True
                    self.plataforma_actual = plataforma
                    break

            # El suelo principal siempre sirve como respaldo.
            if self.rect.bottom >= HEIGHT - 100:
                self.rect.bottom = HEIGHT - 100
                self.vel_y = 0
                self.on_ground = True
                self.plataforma_actual = None

            if self.on_ground:
                self.en_superataque = False
                self.estado_superataque = "normal"
                self.cohete_actual = None
                self.last_shot = ahora

    
    def dibujar_superataque(self, screen, camera_x):
        if not self.en_superataque:
            return

        if self.estado_superataque not in ("aviso", "disparando"):
            return

        if not self.cohete_actual:
            return

        cohete = self.cohete_actual
        rect = cohete["rect"]
        y_centro = rect.centery

        # Franja roja semitransparente que avisa de la trayectoria.
        aviso = pygame.Surface(
            (screen.get_width(), 70),
            pygame.SRCALPHA
        )
        aviso.fill((255, 0, 0, 65))

        screen.blit(aviso, (0, y_centro - 35))

        pygame.draw.line(
            screen,
            (255, 40, 40),
            (0, y_centro),
            (screen.get_width(), y_centro),
            3
        )

        # Durante los 800 ms de aviso NO se dibuja la bala.
        if self.estado_superataque != "disparando":
            return

        if cohete["direccion"] < 0:
            sprite = self.sprite_cohete_gigante_izquierda
        else:
            sprite = self.sprite_cohete_gigante

        screen.blit(
            sprite,
            (
                rect.x - camera_x,
                rect.y
            )
        )


    def comprobar_dano_superataque(self, player):
        if not self.en_superataque or not self.cohete_actual:
            return False

        if self.estado_superataque != "disparando":
            return False

        ahora = pygame.time.get_ticks()
        cohete = self.cohete_actual["rect"]

        if cohete.colliderect(player.rect):
            if ahora - self.ultimo_dano_gigante > 700:
                player.take_damage(self.damage * 2)
                self.ultimo_dano_gigante = ahora
                return True

        return False

    def shoot(self, player, boss_bullets):

        current_time = pygame.time.get_ticks()

        if current_time - self.last_shot < self.shoot_delay:
            return
        
        start_x = self.rect.centerx
        start_y = self.rect.centery

        target_x = player.rect.centerx
        target_y = player.rect.centery

        bala = Bullet(
            start_x,
            start_y,
            target_x,
            target_y,
            BULLET_DM,
            "boss2"
        )

        bala.speed = BULLET_V

        boss_bullets.append(bala)

        self.last_shot = current_time

    def update(self, player, plataformas):

        speed=self.speed

        if player.rect.centerx > self.rect.centerx:
            self.rect.x += speed

        elif player.rect.centerx < self.rect.centerx:
            self.rect.x -= speed

        if (
            self.on_ground
            and
            not self.bajando_plataforma
            and
            self.plataforma_actual is not None
        ):

            if self.jugador_debajo(player):

                self.bajando_plataforma = True

                self.plataforma_actual = self.plataforma_actual

        self.vel_y += GRAVITY

        self.rect.y += self.vel_y

        self.on_ground = False

        for platform in plataformas:

            if not self.rect.colliderect(platform):
                continue

            if self.vel_y <= 0:
                continue

            if self.bajando_plataforma:

                if platform == self.plataforma_actual:
                    continue

                self.rect.bottom = platform.top

                self.vel_y = 0

                self.on_ground = True

                self.bajando_plataforma = False

                self.plataforma_actual = platform

                break

            else:

                self.rect.bottom = platform.top

                self.vel_y = 0

                self.on_ground = True

                self.plataforma_actual = platform

                break

        if self.rect.bottom >= HEIGHT - 100:

            self.rect.bottom = HEIGHT - 100

            self.vel_y = 0

            self.on_ground = True

            self.bajando_plataforma = False

            self.plataforma_actual = None

        if self.jump_cooldown > 0:
            self.jump_cooldown -= 1

        if (
            self.on_ground
            and
            not self.bajando_plataforma
            and
            self.jump_cooldown == 0
        ):

            height_diff = (
                self.rect.bottom -
                player.rect.bottom
            )

            horizontal_diff = abs(
                player.rect.centerx -
                self.rect.centerx
            )

            if (
                height_diff > JUMP_TRIGGER_HEIGHT
                and
                horizontal_diff < JUMP_TRIGGER_DISTANCE
            ):

                self.vel_y = JUMP_FORCE

                self.on_ground = False

                self.plataforma_actual = None

                self.jump_cooldown = (
                    JUMP_COOLDOWN_FRAMES +
                    random.randint(0, 20)
                )

    def jugador_debajo(self, player):

        diferencia_vertical = (
            player.rect.centery -
            self.rect.centery
        )

        abajo = diferencia_vertical > 20


        diferencia_horizontal = abs(
            player.rect.centerx -
            self.rect.centerx
        )

        horizontal = diferencia_horizontal < 150


        return abajo and horizontal

    def take_damage(self, amount):

        self.health -= amount

        self.damaged = True

        self.damage_timer = pygame.time.get_ticks()

    def draw(self, screen, camera_x):

        image = self.sprite.idle.copy()

        if self.damaged:

            if (
                pygame.time.get_ticks() -
                self.damage_timer
                < 100
            ):

                tint = pygame.Surface(
                    image.get_size()
                )

                tint.fill((255, 0, 200))

                image.blit(
                    tint,
                    (0, 0),
                    special_flags=pygame.BLEND_RGB_ADD
                )

            else:

                self.damaged = False

        screen.blit(
            image,
            (
                self.rect.x - camera_x,
                self.rect.y
            )
        )