import pygame
import random

from settings import (
    BOSS_SPEED,
    GRAVITY,
    BOSS_DAMAGE,
    JUMP_COOLDOWN_FRAMES,
    JUMP_FORCE,
    JUMP_TRIGGER_DISTANCE,
    JUMP_TRIGGER_HEIGHT,
    HEIGHT,
    BULLET_DM,
    BULLET_V
)

from bullet import Bullet
from sprites import boss_sprite, boss2_sprite
from difficulty import get_difficulty_config


class Boss:

    def __init__(self, x, y, dificultad=None):

        # ==============================
        # SPRITE
        # ==============================

        self.sprite = boss_sprite()
        self.image = self.sprite.idle

        self.rect = self.image.get_rect(topleft=(x, y))

        # Hitbox ligeramente más pequeña
        self.rect.inflate_ip(-15, -15)

        # ==============================
        # ESTADÍSTICAS
        # ==============================

        stats = (
            dificultad
            if isinstance(dificultad, dict)
            else get_difficulty_config(dificultad)
        )

        self.speed = stats["boss_speed"]
        self.health = stats["boss_health"]
        self.damage = stats["boss_damage"]
        self.max_health = self.health


        # ==============================
        # FÍSICA
        # ==============================

        self.vel_y = 0
        self.on_ground = False

        # Plataforma sobre la que está parado
        self.plataforma_actual = None

        # ==============================
        # BAJAR DE PLATAFORMA
        # ==============================

        self.bajando_plataforma = False

        # ==============================
        # SALTO
        # ==============================

        self.jump_cooldown = 0

        # ==============================
        # DAÑO
        # ==============================

        self.damaged = False
        self.damage_timer = 0


    # =========================================================
    # UPDATE
    # =========================================================

    def update(self, player, plataformas):

        # =====================================================
        # MOVIMIENTO HORIZONTAL
        # =====================================================

        if player.rect.centerx > self.rect.centerx:
            self.rect.x += self.speed

        elif player.rect.centerx < self.rect.centerx:
            self.rect.x -= self.speed


        # =====================================================
        # DECIDIR SI DEBE BAJAR
        # =====================================================

        if (
            self.on_ground
            and
            not self.bajando_plataforma
            and
            self.plataforma_actual is not None
        ):

            if self.jugador_debajo(player):

                self.bajando_plataforma = True

                self.plataforma_actual = self.plataforma_actual


        # =====================================================
        # GRAVEDAD
        # =====================================================

        self.vel_y += GRAVITY

        self.rect.y += self.vel_y

        self.on_ground = False


        # =====================================================
        # COLISIONES CON PLATAFORMAS
        # =====================================================

        for platform in plataformas:

            if not self.rect.colliderect(platform):
                continue

            # Solo colisionamos con plataformas cuando caemos
            if self.vel_y <= 0:
                continue


            # =================================================
            # ESTÁ BAJANDO
            # =================================================

            if self.bajando_plataforma:

                # IGNORAR LA PLATAFORMA DE LA QUE ESTÁ BAJANDO
                if platform == self.plataforma_actual:
                    continue

                # Aterrizar sobre otra plataforma
                self.rect.bottom = platform.top

                self.vel_y = 0

                self.on_ground = True

                self.bajando_plataforma = False

                self.plataforma_actual = platform

                break


            # =================================================
            # COMPORTAMIENTO NORMAL
            # =================================================

            else:

                self.rect.bottom = platform.top

                self.vel_y = 0

                self.on_ground = True

                self.plataforma_actual = platform

                break


        # =====================================================
        # SUELO
        # =====================================================

        if self.rect.bottom >= HEIGHT - 100:

            self.rect.bottom = HEIGHT - 100

            self.vel_y = 0

            self.on_ground = True

            self.bajando_plataforma = False

            self.plataforma_actual = None


        # =====================================================
        # COOLDOWN
        # =====================================================

        if self.jump_cooldown > 0:
            self.jump_cooldown -= 1


        # =====================================================
        # SALTO
        # =====================================================

        if (
            self.on_ground
            and
            not self.bajando_plataforma
            and
            self.jump_cooldown == 0
        ):

            height_diff = (
                self.rect.bottom -
                player.rect.bottom
            )

            horizontal_diff = abs(
                player.rect.centerx -
                self.rect.centerx
            )

            if (
                height_diff > JUMP_TRIGGER_HEIGHT
                and
                horizontal_diff < JUMP_TRIGGER_DISTANCE
            ):

                self.vel_y = JUMP_FORCE

                self.on_ground = False

                self.plataforma_actual = None

                self.jump_cooldown = (
                    JUMP_COOLDOWN_FRAMES +
                    random.randint(0, 20)
                )


    # =========================================================
    # DETECTAR JUGADOR DEBAJO
    # =========================================================

    def jugador_debajo(self, player):

        # El centro del jugador está debajo
        diferencia_vertical = (
            player.rect.centery -
            self.rect.centery
        )

        abajo = diferencia_vertical > 20


        # Distancia horizontal
        diferencia_horizontal = abs(
            player.rect.centerx -
            self.rect.centerx
        )

        horizontal = diferencia_horizontal < 150


        return abajo and horizontal


    # =========================================================
    # RECIBIR DAÑO
    # =========================================================

    def take_damage(self, amount):

        self.health -= amount

        self.damaged = True

        self.damage_timer = pygame.time.get_ticks()


    # =========================================================
    # DIBUJAR
    # =========================================================

    def draw(self, screen, camera_x):

        image = self.sprite.idle.copy()

        if self.damaged:

            if (
                pygame.time.get_ticks() -
                self.damage_timer
                < 100
            ):

                tint = pygame.Surface(
                    image.get_size()
                )

                tint.fill((255, 0, 200))

                image.blit(
                    tint,
                    (0, 0),
                    special_flags=pygame.BLEND_RGB_ADD
                )

            else:

                self.damaged = False

        screen.blit(
            image,
            (
                self.rect.x - camera_x,
                self.rect.y
            )
        )
class Boss2:

    def __init__(self, x, y,dificultad=None):

        self.sprite = boss2_sprite()
        self.image = self.sprite.idle

        self.rect = self.image.get_rect(topleft=(x, y))


        self.rect.inflate_ip(-15, -15)

        stats = (
            dificultad
            if isinstance(dificultad, dict)
            else get_difficulty_config(dificultad)
        )

        self.speed = stats["boss_speed"]
        self.health = stats["boss_health"]
        self.damage = stats["boss_damage"]
        self.max_health = self.health


        self.vel_y = 0
        self.on_ground = False

        self.plataforma_actual = None

        self.bajando_plataforma = False

        self.jump_cooldown = 0

        self.damaged = False
        self.damage_timer = 0
        self.shoot_delay = 1500
        self.last_shot = 0

    def shoot(self, player, boss_bullets):

        current_time = pygame.time.get_ticks()

        if current_time - self.last_shot < self.shoot_delay:
            return
        
        start_x = self.rect.centerx
        start_y = self.rect.centery

        target_x = player.rect.centerx
        target_y = player.rect.centery

        bala = Bullet(
            start_x,
            start_y,
            target_x,
            target_y,
            BULLET_DM,
            "boss2"
        )

        bala.speed = BULLET_V

        boss_bullets.append(bala)

        self.last_shot = current_time

    def update(self, player, plataformas):

        if player.rect.centerx > self.rect.centerx:
            self.rect.x += self.speed

        elif player.rect.centerx < self.rect.centerx:
            self.rect.x -= self.speed

        if (
            self.on_ground
            and
            not self.bajando_plataforma
            and
            self.plataforma_actual is not None
        ):

            if self.jugador_debajo(player):

                self.bajando_plataforma = True

                self.plataforma_actual = self.plataforma_actual

        self.vel_y += GRAVITY

        self.rect.y += self.vel_y

        self.on_ground = False

        for platform in plataformas:

            if not self.rect.colliderect(platform):
                continue

            if self.vel_y <= 0:
                continue

            if self.bajando_plataforma:

                if platform == self.plataforma_actual:
                    continue

                self.rect.bottom = platform.top

                self.vel_y = 0

                self.on_ground = True

                self.bajando_plataforma = False

                self.plataforma_actual = platform

                break

            else:

                self.rect.bottom = platform.top

                self.vel_y = 0

                self.on_ground = True

                self.plataforma_actual = platform

                break

        if self.rect.bottom >= HEIGHT - 100:

            self.rect.bottom = HEIGHT - 100

            self.vel_y = 0

            self.on_ground = True

            self.bajando_plataforma = False

            self.plataforma_actual = None

        if self.jump_cooldown > 0:
            self.jump_cooldown -= 1

        if (
            self.on_ground
            and
            not self.bajando_plataforma
            and
            self.jump_cooldown == 0
        ):

            height_diff = (
                self.rect.bottom -
                player.rect.bottom
            )

            horizontal_diff = abs(
                player.rect.centerx -
                self.rect.centerx
            )

            if (
                height_diff > JUMP_TRIGGER_HEIGHT
                and
                horizontal_diff < JUMP_TRIGGER_DISTANCE
            ):

                self.vel_y = JUMP_FORCE

                self.on_ground = False

                self.plataforma_actual = None

                self.jump_cooldown = (
                    JUMP_COOLDOWN_FRAMES +
                    random.randint(0, 20)
                )

    def jugador_debajo(self, player):

        diferencia_vertical = (
            player.rect.centery -
            self.rect.centery
        )

        abajo = diferencia_vertical > 20


        diferencia_horizontal = abs(
            player.rect.centerx -
            self.rect.centerx
        )

        horizontal = diferencia_horizontal < 150


        return abajo and horizontal

    def take_damage(self, amount):

        self.health -= amount

        self.damaged = True

        self.damage_timer = pygame.time.get_ticks()

    def draw(self, screen, camera_x):

        image = self.sprite.idle.copy()

        if self.damaged:

            if (
                pygame.time.get_ticks() -
                self.damage_timer
                < 100
            ):

                tint = pygame.Surface(
                    image.get_size()
                )

                tint.fill((255, 0, 200))

                image.blit(
                    tint,
                    (0, 0),
                    special_flags=pygame.BLEND_RGB_ADD
                )

            else:

                self.damaged = False

        screen.blit(
            image,
            (
                self.rect.x - camera_x,
                self.rect.y
            )
        )