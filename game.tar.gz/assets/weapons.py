import pygame
from sprites import weapons_sprite

class Weapon:
    def __init__(self, name, ammo, max_ammo, damage, reserve_ammo=0):
        self.sprites = weapons_sprite()
        self.name = name
        self.ammo = ammo
        self.max_ammo = max_ammo
        self.damage = damage
        self.reserve_ammo = reserve_ammo

        self.reloading = False
        self.reload_time = 0
        self.reload_speed = 60

        if self.name == "pistol":
            self.image = self.sprites.pistol
            self.distance = 7

        elif self.name == "shotgun":
            self.image = self.sprites.shotgun
            self.distance = 23

        elif self.name == "raygun" :
            self.image = self.sprites.raygun
            self.distance = 23

        else:
            self.image = self.sprites.pistol
            self.distance = 25

    def shoot(self):
        if self.reloading:
            return False

        if self.ammo > 0 or self.ammo == -1:
            if self.ammo != -1:
                self.ammo -= 1
            return True
        return False

    def start_reload(self):
        if (
            self.ammo != -1
            and self.ammo < self.max_ammo
            and self.reserve_ammo > 0
            and not self.reloading
        ):
            self.reloading = True
            self.reload_time = 0

    def update(self):
        if self.reloading:
            self.reload_time += 1

            if self.reload_time >= self.reload_speed:
                needed = self.max_ammo - self.ammo
                load = min(needed, self.reserve_ammo)

                self.ammo += load
                self.reserve_ammo -= load
                self.reloading = False
    
    def get_direction(self, angle):
        return pygame.math.Vector2(1, 0).rotate(angle)
    
    def draw(self, screen, player_rect, camera_x, angle):
        px, py = player_rect.center

        if angle > 90 or angle < -90:
            image = pygame.transform.flip(self.image, False, True)
            draw_angle = -angle
        else:
            image = self.image
            draw_angle = -angle

        rotated = pygame.transform.rotate(image, -draw_angle)

        direction = self.get_direction(angle)

        offset_x = direction.x * self.distance
        offset_y = -direction.y * self.distance

        rect = rotated.get_rect(center=(px - camera_x + offset_x, py + offset_y))
        screen.blit(rotated, rect)