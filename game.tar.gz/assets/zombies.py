import random
import pygame

from settings import (
    ZOMBIE_SPEED,
    GRAVITY,
    ZOMBIE_DAMAGE,
    HEIGHT,
    JUMP_COOLDOWN_FRAMES,
    JUMP_FORCE,
    JUMP_TRIGGER_DISTANCE,
    JUMP_TRIGGER_HEIGHT
)
from sprites import zombiesprite,zombie_sewer_sprite
from difficulty import get_difficulty_config


class Zombie:

    def __init__(self, x, y, estado="superficie", dificultad=None):

        # ==============================
        # SPRITE
        # ==============================
        if estado=="superficie":
            self.sprite = zombiesprite()
        else:
            self.sprite = zombie_sewer_sprite()
        self.image = self.sprite.idle

        self.rect = self.image.get_rect(
            topleft=(x, y)
        )

        # ==============================
        # ESTADÍSTICAS
        # ==============================

        stats = (
            dificultad
            if isinstance(dificultad, dict)
            else get_difficulty_config(dificultad)
        )

        self.speed = stats["zombie_speed"]
        self.health = stats["zombie_health"]
        self.damage = stats["zombie_damage"]

        # Guardar la vida máxima para futuras barras de vida.
        self.max_health = self.health

        # ==============================
        # FÍSICA
        # ==============================

        self.vel_y = 0
        self.on_ground = False

        # Plataforma actual
        self.plataforma_actual = None

        # ==============================
        # BAJAR
        # ==============================

        self.bajando_plataforma = False

        # ==============================
        # SALTO
        # ==============================

        self.jump_cooldown = 0

        # ==============================
        # DAÑO
        # ==============================

        self.damaged = False
        self.damage_timer = 0

    def update(self, player, plataformas):

        # =====================================================
        # MOVIMIENTO HORIZONTAL
        # =====================================================

        if player.rect.centerx > self.rect.centerx:
            self.rect.x += self.speed

        elif player.rect.centerx < self.rect.centerx:
            self.rect.x -= self.speed


        # =====================================================
        # DECIDIR SI DEBE BAJAR
        # =====================================================

        if (
            self.on_ground
            and
            not self.bajando_plataforma
            and
            self.plataforma_actual is not None
        ):

            if self.jugador_debajo(player):

                self.bajando_plataforma = True


        # =====================================================
        # GRAVEDAD
        # =====================================================

        self.vel_y += GRAVITY

        self.rect.y += self.vel_y

        self.on_ground = False


        # =====================================================
        # COLISIONES
        # =====================================================

        for platform in plataformas:

            if not self.rect.colliderect(platform):
                continue

            if self.vel_y <= 0:
                continue


            # =================================================
            # BAJANDO DE UNA PLATAFORMA
            # =================================================

            if self.bajando_plataforma:

                # Ignorar la plataforma actual
                if platform == self.plataforma_actual:
                    continue

                # Aterrizar en la nueva plataforma
                self.rect.bottom = platform.top

                self.vel_y = 0

                self.on_ground = True

                self.bajando_plataforma = False

                self.plataforma_actual = platform

                break


            # =================================================
            # COMPORTAMIENTO NORMAL
            # =================================================

            else:

                self.rect.bottom = platform.top

                self.vel_y = 0

                self.on_ground = True

                self.plataforma_actual = platform

                break


        # =====================================================
        # SUELO
        # =====================================================

        if self.rect.bottom >= HEIGHT - 100:

            self.rect.bottom = HEIGHT - 100

            self.vel_y = 0

            self.on_ground = True

            self.bajando_plataforma = False

            self.plataforma_actual = None


        # =====================================================
        # COOLDOWN
        # =====================================================

        if self.jump_cooldown > 0:
            self.jump_cooldown -= 1


        # =====================================================
        # SALTO
        # =====================================================

        if (
            self.on_ground
            and
            not self.bajando_plataforma
            and
            self.jump_cooldown == 0
        ):

            height_diff = (
                self.rect.bottom -
                player.rect.bottom
            )

            horizontal_diff = abs(
                player.rect.centerx -
                self.rect.centerx
            )

            if (
                height_diff > JUMP_TRIGGER_HEIGHT
                and
                horizontal_diff < JUMP_TRIGGER_DISTANCE
            ):

                self.vel_y = JUMP_FORCE

                self.on_ground = False

                self.plataforma_actual = None

                self.jump_cooldown = (
                    JUMP_COOLDOWN_FRAMES +
                    random.randint(0, 20)
                )


    # =========================================================
    # JUGADOR DEBAJO
    # =========================================================

    def jugador_debajo(self, player):

        diferencia_vertical = (
            player.rect.centery -
            self.rect.centery
        )

        abajo = diferencia_vertical > 20

        diferencia_horizontal = abs(
            player.rect.centerx -
            self.rect.centerx
        )

        horizontal = diferencia_horizontal < 100

        return abajo and horizontal


    # =========================================================
    # DAÑO
    # =========================================================

    def take_damage(self, amount):

        self.health -= amount

        self.damaged = True

        self.damage_timer = pygame.time.get_ticks()


    # =========================================================
    # DIBUJAR
    # =========================================================

    def draw(self, screen, camera_x):

        image = self.image.copy()

        if self.damaged:

            if (
                pygame.time.get_ticks() -
                self.damage_timer
                < 100
            ):

                tint = pygame.Surface(
                    image.get_size()
                )

                tint.fill((255, 0, 200))

                image.blit(
                    tint,
                    (0, 0),
                    special_flags=pygame.BLEND_RGB_ADD
                )

            else:

                self.damaged = False

        screen.blit(
            image,
            (
                self.rect.x - camera_x,
                self.rect.y
            )
        )