import pygame
from settings import WIDTH,HEIGHT,BOSS_HEALTH


def draw_ui(screen, player, font, level, score):

    bar_w = 200
    ratio = max(0, min(1, player.health / 100))

    if player.health > 50:
        col = (0, 255, 0)
    elif player.health > 30:
        col = (255, 165, 0)
    else:
        col = (255, 0, 0)

    pygame.draw.rect(
        screen,
        (50, 50, 50),
        (20, 20, bar_w, 20)
    )

    pygame.draw.rect(
        screen,
        col,
        (20, 20, bar_w * ratio, 20)
    )

    hp_text = font.render(
        f"{int(player.health)} / 100",
        True,
        (0, 255, 0)
    )

    screen.blit(hp_text, (20, 45))

    level_text = font.render(
        f"nivel: {level}",
        True,
        (255, 0, 0)
    )

    screen.blit(
        level_text,
        (WIDTH - level_text.get_width() - 10, 100)
    )

    score_text = font.render(
        f"Puntos: {score}",
        True,
        (255, 0, 200)
    )

    screen.blit(score_text, (20, 120))


def draw_boss_health(screen, boss, font=None):
    if boss is None or getattr(boss, "health", 0) <= 0:
        return

    # Vida máxima del jefe
    max_health = getattr(boss, "max_health", BOSS_HEALTH)

    if max_health <= 0:
        return

    # Porcentaje de vida restante
    porcentaje = max(0, min(1, boss.health / max_health))

    # Tamaño y posición de la barra
    barra_ancho = 400
    barra_alto = 24
    barra_x = (screen.get_width() - barra_ancho) // 2
    barra_y = 25

    # Fondo oscuro
    pygame.draw.rect(
        screen, (35, 35, 35),
        (barra_x, barra_y, barra_ancho, barra_alto),
        border_radius=6
    )

    # Color progresivo: verde -> amarillo -> rojo
    if porcentaje > 0.5:
        progreso = (1 - porcentaje) * 2
        rojo = int(255 * progreso)
        verde = 255
    else:
        progreso = porcentaje * 2
        rojo = 255
        verde = int(255 * progreso)

    color_vida = (rojo, verde, 0)

    # Barra que disminuye con el daño
    ancho_vida = int(barra_ancho * porcentaje)

    if ancho_vida > 0:
        pygame.draw.rect(
            screen, color_vida,
            (barra_x, barra_y, ancho_vida, barra_alto),
            border_radius=6
        )

    # Borde de la barra
    pygame.draw.rect(
        screen, (230, 230, 230),
        (barra_x, barra_y, barra_ancho, barra_alto),
        width=2,
        border_radius=6
    )

    # Nombre y vida numérica del jefe
    if font is None:
        font = pygame.font.Font(None, 24)

    texto = font.render(
        f"JEFE: {max(0, int(boss.health))}/{max_health} HP",
        True, (255, 255, 255)
    )

    texto_rect = texto.get_rect(
        center=(screen.get_width() // 2, barra_y + barra_alto + 16)
    )

    screen.blit(texto, texto_rect)



def draw_ammo(screen, player, font):

    if player.weapon.reloading:
        text = f"{player.weapon.name}: RECARGANDO..."
        color = (255, 200, 0)

    elif player.weapon.ammo == -1:
        text = f"{player.weapon.name}: ∞"
        color = (255, 0, 0)

    else:
        text = (
            f"{player.weapon.name}: "
            f"{player.weapon.ammo}/"
            f"{player.weapon.reserve_ammo}"
        )
        color = (255, 0, 0)

    render = font.render(text, True, color)
    screen.blit(render, (20, 80))

def draw_touch_controls(screen):
    """Dibuja los controles táctiles de Exodo Z."""

    from settings import HEIGHT

    controls = {
        "left": pygame.Rect(20, HEIGHT - 125, 85, 85),
        "right": pygame.Rect(115, HEIGHT - 125, 85, 85),
        "jump": pygame.Rect(WIDTH - 285, HEIGHT - 125, 85, 85),
        "shoot": pygame.Rect(WIDTH - 105, HEIGHT - 125, 90, 90),

        "weapon1": pygame.Rect(WIDTH - 240, HEIGHT - 230, 65, 60),
        "weapon2": pygame.Rect(WIDTH - 170, HEIGHT - 230, 65, 60),
        "weapon3": pygame.Rect(WIDTH - 100, HEIGHT - 230, 65, 60),

        "reload": pygame.Rect(WIDTH - 240, HEIGHT - 160, 65, 45),
        "surface": pygame.Rect(WIDTH - 170, HEIGHT - 160, 65, 45),

        "pause": pygame.Rect(WIDTH - 74, 18, 56, 56),
    }

    labels = {
        "left": "<",
        "right": ">",
        "jump": "SALTO",
        "shoot": "DISPARAR",
        "weapon1": "1",
        "weapon2": "2",
        "weapon3": "3",
        "reload": "R",
        "surface": "S",
    }

    for name, rect in controls.items():
        pygame.draw.rect(
            screen,
            (100, 20, 25, 210),
            rect,
            border_radius=12,
        )

        pygame.draw.rect(
            screen,
            (255, 90, 90),
            rect,
            width=2,
            border_radius=12,
        )

        label = pygame.font.SysFont("arial", 20, bold=True)
        text = label.render(labels[name], True, (255, 255, 255))
        screen.blit(text, text.get_rect(center=rect.center))

    return controls

def draw_pause_button(screen, mouse_pos):

    size = 56

    rect = pygame.Rect(
        WIDTH - size - 18,
        18,
        size,
        size
    )

    hover = rect.collidepoint(mouse_pos)

    center = rect.center

    bg_color = (
        (65, 65, 65)
        if not hover
        else (90, 90, 90)
    )

    pygame.draw.circle(
        screen,
        bg_color,
        center,
        27
    )

    pygame.draw.circle(
        screen,
        (220, 220, 220),
        center,
        27,
        2
    )

    emoji_font = pygame.font.SysFont(
        "Segoe UI Emoji",
        38
    )

    emoji = emoji_font.render(
        "⚙️",
        True,
        (255, 255, 255)
    )

    emoji_rect = emoji.get_rect(
        center=center
    )

    screen.blit(
        emoji,
        emoji_rect
    )

    return rect

def draw_pause_menu(
    screen,
    mouse_pos,
    confirm_exit=False,
    confirm_restart=False
):

    overlay = pygame.Surface(
        (WIDTH, 600),
        pygame.SRCALPHA
    )

    overlay.fill(
        (0, 0, 0, 150)
    )

    screen.blit(
        overlay,
        (0, 0)
    )

    panel = pygame.Rect(
        0,
        0,
        430,
        390
    )

    panel.center = (
        WIDTH // 2,
        600 // 2
    )

    pygame.draw.rect(
        screen,
        (35, 35, 35),
        panel,
        border_radius=12
    )

    pygame.draw.rect(
        screen,
        (220, 220, 220),
        panel,
        3,
        border_radius=12
    )

    title_font = pygame.font.SysFont(
        "arial",
        48,
        bold=True
    )

    button_font = pygame.font.SysFont(
        "arial",
        30,
        bold=True
    )

    small_font = pygame.font.SysFont(
        "arial",
        24
    )

    title = title_font.render(
        "PAUSA",
        True,
        (255, 255, 255)
    )

    screen.blit(
        title,
        title.get_rect(
            center=(
                panel.centerx,
                panel.top + 55
            )
        )
    )

    close_rect = pygame.Rect(
        panel.right - 48,
        panel.top + 15,
        32,
        32
    )

    close_hover = close_rect.collidepoint(
        mouse_pos
    )

    pygame.draw.rect(
        screen,
        (170, 45, 45)
        if close_hover
        else (120, 35, 35),
        close_rect,
        border_radius=6
    )

    pygame.draw.line(
        screen,
        (255, 255, 255),
        (
            close_rect.left + 8,
            close_rect.top + 8
        ),
        (
            close_rect.right - 8,
            close_rect.bottom - 8
        ),
        3
    )

    pygame.draw.line(
        screen,
        (255, 255, 255),
        (
            close_rect.right - 8,
            close_rect.top + 8
        ),
        (
            close_rect.left + 8,
            close_rect.bottom - 8
        ),
        3
    )

    if confirm_exit or confirm_restart:

        if confirm_restart:

            warning = small_font.render(
                "¿Seguro que quieres reiniciar?",
                True,
                (255, 220, 100)
            )

            warning2 = small_font.render(
                "Perderás el progreso de esta partida.",
                True,
                (255, 255, 255)
            )

            yes_text = "SÍ"

        else:

            warning = small_font.render(
                "¿Seguro que quieres salir?",
                True,
                (255, 220, 100)
            )

            warning2 = small_font.render(
                "Se cerrará el juego.",
                True,
                (255, 255, 255)
            )

            yes_text = "SÍ"

        screen.blit(
            warning,
            warning.get_rect(
                center=(
                    panel.centerx,
                    panel.top + 120
                )
            )
        )

        screen.blit(
            warning2,
            warning2.get_rect(
                center=(
                    panel.centerx,
                    panel.top + 150
                )
            )
        )

        yes_rect = pygame.Rect(
            0,
            0,
            180,
            55
        )

        no_rect = pygame.Rect(
            0,
            0,
            160,
            55
        )

        yes_rect.center = (
            panel.centerx - 95,
            panel.centery + 65
        )

        no_rect.center = (
            panel.centerx + 95,
            panel.centery + 65
        )

        def draw_button(
            rect,
            text,
            normal,
            hover
        ):

            color = (
                hover
                if rect.collidepoint(mouse_pos)
                else normal
            )

            pygame.draw.rect(
                screen,
                color,
                rect,
                border_radius=8
            )

            pygame.draw.rect(
                screen,
                (235, 235, 235),
                rect,
                2,
                border_radius=8
            )

            label = button_font.render(
                text,
                True,
                (255, 255, 255)
            )

            screen.blit(
                label,
                label.get_rect(
                    center=rect.center
                )
            )

        draw_button(
            yes_rect,
            yes_text,
            (150, 30, 30),
            (210, 50, 50)
        )

        draw_button(
            no_rect,
            "NO",
            (60, 100, 60),
            (80, 140, 80)
        )

        return {
            "close": close_rect,
            "resume": None,
            "restart": None,
            "exit": None,
            "confirm_yes": yes_rect,
            "confirm_no": no_rect
        }

    button_w = 260
    button_h = 58

    x = (
        panel.centerx
        - button_w // 2
    )

    resume_rect = pygame.Rect(
        x,
        panel.top + 105,
        button_w,
        button_h
    )

    restart_rect = pygame.Rect(
        x,
        panel.top + 180,
        button_w,
        button_h
    )

    exit_rect = pygame.Rect(
        x,
        panel.top + 255,
        button_w,
        button_h
    )

    def draw_button(
        rect,
        text
    ):

        color = (
            (55, 130, 70)
            if rect.collidepoint(mouse_pos)
            else (40, 100, 55)
        )

        if text == "REINICIAR":

            color = (
                (180, 125, 35)
                if rect.collidepoint(mouse_pos)
                else (145, 95, 25)
            )

        elif text == "SALIR":

            color = (
                (180, 45, 45)
                if rect.collidepoint(mouse_pos)
                else (130, 35, 35)
            )

        pygame.draw.rect(
            screen,
            color,
            rect,
            border_radius=8
        )

        pygame.draw.rect(
            screen,
            (235, 235, 235),
            rect,
            2,
            border_radius=8
        )

        label = button_font.render(
            text,
            True,
            (255, 255, 255)
        )

        screen.blit(
            label,
            label.get_rect(
                center=rect.center
            )
        )

    draw_button(
        resume_rect,
        "REANUDAR"
    )

    draw_button(
        restart_rect,
        "REINICIAR"
    )

    draw_button(
        exit_rect,
        "SALIR"
    )

    return {
        "close": close_rect,
        "resume": resume_rect,
        "restart": restart_rect,
        "exit": exit_rect,
        "confirm_yes": None,
        "confirm_no": None
    }