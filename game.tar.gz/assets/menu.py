import pygame

def draw_menu(screen, background, WIDTH, HEIGHT, mouse_pos):

    screen.blit(background, (0, 0))

    overlay = pygame.Surface((WIDTH, HEIGHT))
    overlay.set_alpha(180)
    overlay.fill((0, 0, 0))
    screen.blit(overlay, (0, 0))

    title_font = pygame.font.SysFont("arial", 80, bold=True)
    button_font = pygame.font.SysFont("arial", 40)
    controls_font = pygame.font.SysFont("arial", 24)

    title = title_font.render("EXODO Z", True, (255, 0, 0))
    title_rect = title.get_rect(center=(WIDTH // 2, HEIGHT // 5))
    screen.blit(title, title_rect)

    control_titulo = [
         "CONTROLES"
    ]
    controls_derecha = [
        "W = Saltar",
        "A = Caminar a la izquierda",
        "D = Caminar a la derecha",
        "S = Cambiar mapa"
    ]
    controls_izquierda = [
        "Click Izquierdo = Disparar",
        "1 = Pistola",
        "2 = Escopeta",
        "3 = raygun",
        "R = Recargar"
    ]

    y = HEIGHT // 3.7 + 20

    for line in control_titulo:
        text = controls_font.render(line, True, (255, 255, 255))
        rect = text.get_rect(center=(WIDTH // 2, y))
        screen.blit(text, rect)
        y += 30

    for line in controls_derecha:
        text = controls_font.render(line, True, (255, 255, 255))
        rect = text.get_rect(center=(WIDTH // 4, y))
        screen.blit(text, rect)
        y += 30

    y = HEIGHT // 3.1 + 20

    for line in controls_izquierda:
            text = controls_font.render(line, True, (255, 255, 255))
            rect = text.get_rect(center=(WIDTH * 3 // 4, y))
            screen.blit(text, rect)
            y += 30

    button = pygame.Rect(0, 0, 250, 70)
    button.center = (WIDTH // 2, HEIGHT - 120)

    hover = button.collidepoint(mouse_pos)
    color = (255, 50, 50) if hover else (200, 0, 0)

    pygame.draw.rect(screen, color, button)
    pygame.draw.rect(screen, (255, 0, 0), button, 3)

    text = button_font.render("COMENZAR", True, (255, 255, 255))
    screen.blit(text, text.get_rect(center=button.center))

    return button


def draw_game_over(screen, background, WIDTH, HEIGHT, mouse_pos):
    screen.blit(background, (0, 0))

    overlay = pygame.Surface((WIDTH, HEIGHT))
    overlay.set_alpha(180)
    overlay.fill((0, 0, 0))
    screen.blit(overlay, (0, 0))

    title_font = pygame.font.SysFont("arial", 80, bold=True)
    button_font = pygame.font.SysFont("arial", 40)

    text = "GAME OVER"

    base = title_font.render(text, True, (0, 0, 0))
    outline = title_font.render(text, True, (255, 0, 0))

    rect = base.get_rect(center=(WIDTH // 2, HEIGHT // 3))

    for dx in [-2, 2]:
        for dy in [-2, 2]:
            screen.blit(outline, rect.move(dx, dy))

    screen.blit(base, rect)

    button = pygame.Rect(0, 0, 300, 70)
    button.center = (WIDTH // 2, HEIGHT // 2 + 80)

    hover = button.collidepoint(mouse_pos)

    color = (255, 50, 50) if hover else (200, 0, 0)

    pygame.draw.rect(screen, color, button)
    pygame.draw.rect(screen, (255, 0, 0), button, 3)

    text = button_font.render("REINTENTAR", True, (255, 255, 255))
    screen.blit(text, text.get_rect(center=button.center))

    return button